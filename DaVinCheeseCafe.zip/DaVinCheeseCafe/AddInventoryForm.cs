﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Contracts;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace DaVinCheeseCafe
{
    public partial class AddInventoryForm : UserControl
    {
        public AddInventoryForm()
        {
            InitializeComponent();
        }
        public void PopulateGrid()
        {
            string cnstring = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";
            string sqlquery = "SELECT I.ProductID, P.Name AS ProductName, SUM(I.Quantity) AS TotalQuantity FROM Inventories AS I JOIN Products AS P ON I.ProductID = P.ProductID GROUP BY I.ProductID, P.Name HAVING SUM(I.Quantity) < 50; ";
            dataGridView1.Rows.Clear();
            using (SqlConnection con = new SqlConnection(cnstring))
            {
                con.Open();
                using (SqlCommand cm = new SqlCommand(sqlquery, con))
                {
                    using (SqlDataReader reader = cm.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            dataGridView1.Rows.Add(reader["ProductID"], reader["ProductName"], reader["TotalQuantity"]);
                        }
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string proid = textBox1.Text;
            string qty = textBox2.Text;
            int ProductID= int.Parse(proid);
            int Quantity=int.Parse(qty);
           
            string cnstring = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";
            string sqlquery = "select ProductID from Products where ProductID=@ProductID";
            try
            {
                using (SqlConnection con = new SqlConnection(cnstring))
                {
                    con.Open();
                    using (SqlCommand cm = new SqlCommand(sqlquery, con))
                    {
                        cm.Parameters.AddWithValue("@ProductID", ProductID);
                        int productid = Convert.ToInt32(cm.ExecuteScalar());
                        if (productid == ProductID)
                        {
                            sqlquery = "UPDATE Inventories SET Quantity=Quantity+@Quantity WHERE ProductID=@ProductID;";
                            using (SqlCommand cm1 = new SqlCommand(sqlquery, con))
                            {
                                cm1.Parameters.AddWithValue("@ProductID", ProductID);
                                cm1.Parameters.AddWithValue("@Quantity", Quantity);
                                cm1.ExecuteNonQuery();
                            }
                        }
                        else
                        {
                            MessageBox.Show("ProductID does not exist", "Invalid ProductID", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                MessageBox.Show("Record inserted successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
