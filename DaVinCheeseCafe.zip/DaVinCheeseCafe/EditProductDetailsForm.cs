﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;
namespace DaVinCheeseCafe
{
    public partial class EditProductDetailsForm : UserControl
    {
        public EditProductDetailsForm()
        {
            InitializeComponent();
        }

        public void FetchProducts()
        {
            dataGridView3.Rows.Clear();
            string cnstring = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";
            string sqlquery = "select Name,Price,Calories,Description from Products; ";
            try
            {
                using (SqlConnection con = new SqlConnection(cnstring))
                {
                    con.Open();
                    using (SqlCommand cm = new SqlCommand(sqlquery, con))
                    {
                        SqlDataReader dr = cm.ExecuteReader();
                        while (dr.Read())
                        {
                            dataGridView3.Rows.Add(dr["Name"].ToString(), dr["Price"].ToString(), dr["Calories"].ToString(), dr["Description"].ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
