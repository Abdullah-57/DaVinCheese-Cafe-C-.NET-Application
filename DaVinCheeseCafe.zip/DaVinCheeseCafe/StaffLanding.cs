﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace DaVinCheeseCafe
{
    public partial class StaffLanding : Form
    {
        private int ActiveID;
        public StaffLanding(int id)
        {
            InitializeComponent();
            ActiveID = id;
        }
        private bool trig1=false, trig2=false, trig3=false, trig4=false, trig5=false;
        private bool trig6 = false, trig7 = false;

        private void label1_MouseClick(object sender, MouseEventArgs e)
        {
            staffHome1.activeID= ActiveID;
            staffHome1.FetchStaffData();
            staffHome1.Visible=staffHome1.Visible ? false : true;
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (trig7 == false)
            {
                trig7 = true;
                button1.BackColor = Color.IndianRed;
                salesForEachCustomer1.Visible = true;
                salesForEachCustomer1.FetchAllSales();
                this.BackColor = Color.DarkSalmon;
            }
            else
            {
                trig7 = false;
                salesForEachCustomer1.Visible = false;
                button1.BackColor = Color.Firebrick;
                this.BackColor = Color.RosyBrown;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {

            if (trig1 == false)
            {
                trig1 = true;
                button5.BackColor = Color.IndianRed;
                addMenuItem1.Visible = true;
                this.BackColor = Color.DarkSalmon;
            }
            else
            {
                trig1 = false;
                button5.BackColor = Color.Firebrick;
                addMenuItem1.Visible = false;
                this.BackColor = Color.RosyBrown;
            }

        }
        private void button3_Click(object sender, EventArgs e)
        {
            if (trig2 == false)
            {
                productFeedbackViewer1.publicFetchFeedbacks();
                trig2 = true;
                button3.BackColor = Color.IndianRed;
                productFeedbackViewer1.Visible = true;

            }
            else
            {
                trig2 = false;
                productFeedbackViewer1.Visible = false;
                button3.BackColor = Color.Firebrick;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {

            if (trig3 == false)
            {
                trig3 = true;
                button4.BackColor = Color.IndianRed;
                this.BackColor = Color.DarkSalmon;
                viewOrders1.Visible = true;
            }
            else
            {
                trig3 = false;
                button4.BackColor = Color.Firebrick;
                viewOrders1.Visible = false;
                this.BackColor = Color.RosyBrown;
            }
        }

      

        private void button2_Click(object sender, EventArgs e)
        {

            if (trig5 == false)
            {
                trig5 = true;
                button2.BackColor = Color.IndianRed;
                reservationsViewer1.Visible = true;
                this.BackColor = Color.DarkSalmon;
            }
            else
            {
                trig5 = false;
                reservationsViewer1.Visible = false;
                button2.BackColor = Color.Firebrick;
                this.BackColor = Color.RosyBrown;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {

            if (trig6 == false)
            {
                trig6 = true;
                button6.BackColor = Color.IndianRed;
                editMenuItems1.Visible = true;
                editMenuItems1.GetAllProducts();
                this.BackColor = Color.DarkSalmon;
            }
            else
            {
                trig6 = false;
                editMenuItems1.Visible = false;
                button6.BackColor = Color.Firebrick;
                this.BackColor = Color.RosyBrown;
            }
        }

        

    
    }
}
