﻿namespace DaVinCheeseCafe
{
    partial class MenuItems
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.MenuGrid = new System.Windows.Forms.DataGridView();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Calories = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button1 = new System.Windows.Forms.Button();
            this.minusqtrybrn = new System.Windows.Forms.Button();
            this.addqtybtn = new System.Windows.Forms.Button();
            this.itemqty = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.feedback1 = new DaVinCheeseCafe.Feedback();
            ((System.ComponentModel.ISupportInitialize)(this.MenuGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // MenuGrid
            // 
            this.MenuGrid.BackgroundColor = System.Drawing.Color.IndianRed;
            this.MenuGrid.ColumnHeadersHeight = 29;
            this.MenuGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column2,
            this.Price,
            this.Calories,
            this.Description});
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Perpetua Titling MT", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.MenuGrid.DefaultCellStyle = dataGridViewCellStyle1;
            this.MenuGrid.GridColor = System.Drawing.SystemColors.ControlText;
            this.MenuGrid.Location = new System.Drawing.Point(0, 0);
            this.MenuGrid.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MenuGrid.Name = "MenuGrid";
            this.MenuGrid.ReadOnly = true;
            this.MenuGrid.RowHeadersWidth = 51;
            this.MenuGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.MenuGrid.Size = new System.Drawing.Size(939, 364);
            this.MenuGrid.TabIndex = 0;
            this.MenuGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.MenuGrid_CellContentClick);
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column2.FillWeight = 200F;
            this.Column2.HeaderText = "Name";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Price
            // 
            this.Price.HeaderText = "Price";
            this.Price.MinimumWidth = 6;
            this.Price.Name = "Price";
            this.Price.ReadOnly = true;
            this.Price.Width = 125;
            // 
            // Calories
            // 
            this.Calories.HeaderText = "Calories";
            this.Calories.MinimumWidth = 6;
            this.Calories.Name = "Calories";
            this.Calories.ReadOnly = true;
            this.Calories.Width = 125;
            // 
            // Description
            // 
            this.Description.HeaderText = "Description";
            this.Description.MinimumWidth = 6;
            this.Description.Name = "Description";
            this.Description.ReadOnly = true;
            this.Description.Width = 430;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Column1";
            this.Column1.MinimumWidth = 40;
            this.Column1.Name = "Column1";
            this.Column1.Width = 125;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Firebrick;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button1.FlatAppearance.BorderSize = 2;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Perpetua Titling MT", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.button1.Location = new System.Drawing.Point(767, 457);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(141, 55);
            this.button1.TabIndex = 1;
            this.button1.Text = "ADD TO CART";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // minusqtrybrn
            // 
            this.minusqtrybrn.BackColor = System.Drawing.Color.White;
            this.minusqtrybrn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.minusqtrybrn.Font = new System.Drawing.Font("Perpetua Titling MT", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minusqtrybrn.Location = new System.Drawing.Point(767, 394);
            this.minusqtrybrn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.minusqtrybrn.Name = "minusqtrybrn";
            this.minusqtrybrn.Size = new System.Drawing.Size(32, 33);
            this.minusqtrybrn.TabIndex = 3;
            this.minusqtrybrn.Text = "-";
            this.minusqtrybrn.UseVisualStyleBackColor = false;
            this.minusqtrybrn.Click += new System.EventHandler(this.minusqtrybrn_Click);
            // 
            // addqtybtn
            // 
            this.addqtybtn.BackColor = System.Drawing.Color.White;
            this.addqtybtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addqtybtn.Font = new System.Drawing.Font("Perpetua Titling MT", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addqtybtn.Location = new System.Drawing.Point(858, 394);
            this.addqtybtn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.addqtybtn.Name = "addqtybtn";
            this.addqtybtn.Size = new System.Drawing.Size(32, 33);
            this.addqtybtn.TabIndex = 4;
            this.addqtybtn.Text = "+";
            this.addqtybtn.UseVisualStyleBackColor = false;
            this.addqtybtn.Click += new System.EventHandler(this.addqtybtn_Click);
            // 
            // itemqty
            // 
            this.itemqty.AutoSize = true;
            this.itemqty.Font = new System.Drawing.Font("Perpetua Titling MT", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemqty.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.itemqty.Location = new System.Drawing.Point(818, 394);
            this.itemqty.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.itemqty.Name = "itemqty";
            this.itemqty.Size = new System.Drawing.Size(27, 26);
            this.itemqty.TabIndex = 5;
            this.itemqty.Text = "0";
            this.itemqty.Click += new System.EventHandler(this.itemqty_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Orange;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button2.FlatAppearance.BorderSize = 2;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Perpetua Titling MT", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.Location = new System.Drawing.Point(767, 592);
            this.button2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(141, 55);
            this.button2.TabIndex = 6;
            this.button2.Text = "Product Feedback";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // feedback1
            // 
            this.feedback1.BackColor = System.Drawing.Color.RosyBrown;
            this.feedback1.Location = new System.Drawing.Point(0, 363);
            this.feedback1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.feedback1.Name = "feedback1";
            this.feedback1.Size = new System.Drawing.Size(752, 312);
            this.feedback1.TabIndex = 7;
            this.feedback1.Visible = false;
            // 
            // MenuItems
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSalmon;
            this.Controls.Add(this.feedback1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.itemqty);
            this.Controls.Add(this.addqtybtn);
            this.Controls.Add(this.minusqtrybrn);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.MenuGrid);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "MenuItems";
            this.Size = new System.Drawing.Size(934, 675);
            ((System.ComponentModel.ISupportInitialize)(this.MenuGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView MenuGrid;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button minusqtrybrn;
        private System.Windows.Forms.Button addqtybtn;
        private System.Windows.Forms.Label itemqty;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn Calories;
        private System.Windows.Forms.DataGridViewTextBoxColumn Description;
        private System.Windows.Forms.Button button2;
        private Feedback feedback1;
    }
}
