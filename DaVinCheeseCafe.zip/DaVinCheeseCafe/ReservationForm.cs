﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace DaVinCheeseCafe
{
    public partial class ReservationForm : UserControl
    {
        public int userID;
        public ReservationForm()
        {

            InitializeComponent();
            pictureBox1.Tag = 1;
            pictureBox2.Tag = 2;
            pictureBox3.Tag = 3;
            pictureBox4.Tag = 4;
            pictureBox5.Tag = 5;
            pictureBox6.Tag = 6;
            pictureBox7.Tag = 7;
            pictureBox8.Tag = 8;
            pictureBox9.Tag = 9;
            pictureBox10.Tag = 10;
            pictureBox11.Tag = 11;
            pictureBox12.Tag = 12;
            pictureBox13.Tag = 13;
            pictureBox14.Tag = 14;
            pictureBox15.Tag = 15;

        }
        private bool toggleimage = false;
        List<int> ReservedTables = new List<int>();


        private void PictureBox_Click(object sender, EventArgs e)
        {
            PictureBox pictureBox = sender as PictureBox;

            if (pictureBox == null)
                return;

            int tableNumber = Convert.ToInt32(pictureBox.Tag);

            if (toggleimage)
            {
                pictureBox.BackgroundImage = Image.FromFile(@"G:\My Drive\Classroom\Semester - 4\SP24-DB-E Database System\Project\DaVinCheeseCafe\Assets\icons8-table-501.png");
                toggleimage = false;
                ReservedTables.Remove(tableNumber);
            }
            else
            {
                if (ReservedTables.Count >= 2)
                {
                    MessageBox.Show("You can only reserve 2 tables at a time");
                    return;
                }
                pictureBox.BackgroundImage = Image.FromFile(@"G:\My Drive\Classroom\Semester - 4\SP24-DB-E Database System\Project\DaVinCheeseCafe\Assets\icons8-table-50.png");
                toggleimage = true;
                ReservedTables.Add(tableNumber);
            }
        }

        private int CustomerID;
        private void reservebtn_Click(object sender, EventArgs e)
        {
            if (ReservedTables.Count == 0)
            {
                MessageBox.Show("Please select a table to reserve");
                return;
            }

            int customerActionID = 0;

            string cnstring = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";
            string sqlquery = "select Customers.CustomerID from Customers where Customers.UserID=@UserID;";

            try
            {
                using (SqlConnection con = new SqlConnection(cnstring))
                {
                    con.Open();
                    using (SqlCommand cm = new SqlCommand(sqlquery, con))
                    {
                        cm.Parameters.AddWithValue("@UserID", userID);
                        object result = cm.ExecuteScalar();
                        if (result != null)
                        {
                            CustomerID = Convert.ToInt32(result);
                        }
                    }

                    sqlquery = "INSERT INTO CustomerActions (CustomerID, ActionDate, ActionTime) VALUES (@CustomerID, @Date, @Time);";

                    using (SqlCommand cm = new SqlCommand(sqlquery, con))
                    {
                        
                        cm.Parameters.AddWithValue("@CustomerID", CustomerID);
                        cm.Parameters.AddWithValue("@Date", DatetimePicker.Value.Date);
                        cm.Parameters.AddWithValue("@Time", DatetimePicker.Value.TimeOfDay);
                        cm.ExecuteNonQuery();
                    }
                }

                foreach (int tableNo in ReservedTables)
                {
                    try
                    {
                        using (SqlConnection con = new SqlConnection(cnstring))
                        {
                            con.Open();

                            string checkCustomerReservationsSql = "select COUNT(*) from Reservations R join CustomerActions ca on R.CustomerActionID = ca.ActionID where ca.CustomerID = @CustomerID;";
                            int customerReservations;
                            using (SqlCommand cm = new SqlCommand(checkCustomerReservationsSql, con))
                            {
                                cm.Parameters.AddWithValue("@CustomerID", CustomerID);
                                customerReservations = Convert.ToInt32(cm.ExecuteScalar());
                            }

                            if (customerReservations >= 2)
                            {
                                MessageBox.Show("You can only reserve up to 2 tables at a time.");
                                foreach (Control c in this.Controls)
                                {
                                    if (c is PictureBox)
                                    {
                                        PictureBox pb = c as PictureBox;
                                        pb.BackgroundImage = Image.FromFile(@"G:\My Drive\Classroom\Semester - 4\SP24-DB-E Database System\Project\DaVinCheeseCafe\Assets\icons8-table-501.png");
                                    }
                                }
                                return;
                            }

                            string checkReservationSql = "SELECT COUNT(*) FROM Reservations WHERE TableNo = @TableNo;";
                            int existingReservations;
                            using (SqlCommand cm = new SqlCommand(checkReservationSql, con))
                            {
                                cm.Parameters.AddWithValue("@TableNo", tableNo);
                                existingReservations = Convert.ToInt32(cm.ExecuteScalar());
                            }

                            if (existingReservations > 0)
                            {
                                MessageBox.Show($"Table {tableNo} is already reserved. Please select another table.");
                                continue;
                            }

                            string customerActionSql = "INSERT INTO CustomerActions (CustomerID, ActionDate, ActionTime) VALUES (@CustomerID, GETDATE(), CONVERT(time, GETDATE())); SELECT SCOPE_IDENTITY();";
                            using (SqlCommand cm = new SqlCommand(customerActionSql, con))
                            {
                                cm.Parameters.AddWithValue("@CustomerID", CustomerID);
                                customerActionID = Convert.ToInt32(cm.ExecuteScalar());
                            }

                            string reservationSql = "INSERT INTO Reservations (TableNo, CustomerActionID) VALUES (@TableNo, @CustomerActionID);";
                            using (SqlCommand cm = new SqlCommand(reservationSql, con))
                            {
                                cm.Parameters.AddWithValue("@TableNo", tableNo);
                                cm.Parameters.AddWithValue("@CustomerActionID", customerActionID);
                                cm.ExecuteNonQuery();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                MessageBox.Show("Table reserved successfully");
                ReservedTables.Clear();
                foreach (Control c in this.Controls)
                {
                    if (c is PictureBox)
                    {
                        PictureBox pb = c as PictureBox;
                        pb.BackgroundImage = Image.FromFile(@"G:\My Drive\Classroom\Semester - 4\SP24-DB-E Database System\Project\DaVinCheeseCafe\Assets\icons8-table-501.png");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        
    }
}