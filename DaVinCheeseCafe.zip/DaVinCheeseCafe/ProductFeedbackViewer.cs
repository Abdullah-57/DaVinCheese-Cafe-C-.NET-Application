﻿using System.Data.SqlClient;
using System.Windows.Forms;

namespace DaVinCheeseCafe
{
    public partial class ProductFeedbackViewer : UserControl
    {
        public ProductFeedbackViewer()
        {
            InitializeComponent();
        }

        public void publicFetchFeedbacks()
        {
            dataGridView1.Rows.Clear();
            string cnstring = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";
            string sqlquery = "select C.CustomerID,PF.MenuItemID,F.Remarks from Customers C join  CustomerActions CA on C.CustomerID=CA.CustomerID join Feedbacks F on Ca.ActionID=F.CustomerActionID join ProductFeedbacks PF on PF.FeedbackID=F.FeedbackID;";

            using (SqlConnection cn = new SqlConnection(cnstring))
            {
                cn.Open();
                using (SqlCommand cmd = new SqlCommand(sqlquery, cn))
                {
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            dataGridView1.Rows.Add(dr["CustomerID"].ToString(), dr["MenuItemID"].ToString(), dr["Remarks"].ToString());
                        }
                    }
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
