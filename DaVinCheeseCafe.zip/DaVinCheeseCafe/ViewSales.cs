﻿using System.Data.SqlClient;
using System.Windows.Forms;

namespace DaVinCheeseCafe
{
    public partial class ViewSales : UserControl
    {
        public ViewSales()
        {
            InitializeComponent();
        }

        public void PopulateGrid()
        {
            dataGridView2.Rows.Clear();
            string sqlQuery = "select I.InvoiceID,I.InvoiceDate,I.InvoiceTime,I.Amount,U.FirstName,U.LastName from Sales S join Invoices I on S.InvoiceID=I.InvoiceID join Customers C on I.CustomerID=C.CustomerID join Users U on C.UserID=U.UserID;";
            string cnstring = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";

            using (SqlConnection con = new SqlConnection(cnstring))
            {
                con.Open();
                using (SqlCommand cm = new SqlCommand(sqlQuery, con))
                {
                    using (SqlDataReader dr = cm.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                dataGridView2.Rows.Add(dr[0], dr[1], dr[2], dr[3], dr[4] + " " + dr[5]);
                            }
                        }
                        else
                        {
                            MessageBox.Show("No data available.");
                        }
                    }
                }
            }
        }
        public void FindStarAndDog()
        {
            string cnstring = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";
            string sqlQuery = "select P.Name from Products P where P.Price=(select MAX(Price) from Products);";

            using (SqlConnection con = new SqlConnection(cnstring))
            {
                con.Open();
                using (SqlCommand cm = new SqlCommand(sqlQuery, con))
                {
                    using (SqlDataReader dr = cm.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                label5.Text = dr[0].ToString();
                            }
                        }
                        else
                        {
                            MessageBox.Show("No data available.");
                        }
                    }
                }
                sqlQuery = "select P.Name from Products P where P.Price=(select MIN(Price) from Products);";
                using (SqlCommand cm = new SqlCommand(sqlQuery, con))
                {
                    using (SqlDataReader dr = cm.ExecuteReader())
                    {
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                label4.Text = dr[0].ToString();
                            }
                        }
                        else
                        {
                            MessageBox.Show("No data available.");
                        }
                    }
                }
            }

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
