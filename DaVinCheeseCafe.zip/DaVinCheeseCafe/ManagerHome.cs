﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DaVinCheeseCafe
{
    public partial class ManagerHome : UserControl
    {
        public int activeId;
        public ManagerHome()
        {
            InitializeComponent();  
        }
        public void FetchManagerData() 
        {
            string sqlQuery = "SELECT U.FirstName, U.LastName,U.ContactNo, M.AuthorityLevel,U.Password, SUM(I.Quantity) AS TotalQuantity,U.Email FROM Managers M JOIN Users U ON M.UserID = U.UserID JOIN Inventories I ON M.InventoryID = I.InventoryID WHERE M.ManagerID = 1 GROUP BY U.FirstName,U.LastName,U.ContactNo,U.Email,M.AuthorityLevel,U.Password,U.Email;";

            string cnString = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";
            SqlConnection cn = new SqlConnection(cnString);
            SqlCommand cmd = new SqlCommand(sqlQuery, cn);
            cn.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {

                label2.Text ="MR. "+ dr["FirstName"].ToString()+" "+ dr["LastName"].ToString();
                label9.Text = dr["ContactNo"].ToString();
                label10.Text = dr["AuthorityLevel"].ToString();
                label8.Text = dr["Password"].ToString();
                label6.Text = dr["TotalQuantity"].ToString();
                label7.Text = dr["Email"].ToString();

            }

        }
        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
    }
}
