﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DaVinCheeseCafe
{
    public partial class AddMenuItem : UserControl
    {
        public AddMenuItem()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string name = textBox1.Text;
            string calories = textBox2.Text;
            string price = textBox4.Text;
            string description = textBox3.Text;
            string cnstring = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";

            string sqlquery = "INSERT INTO Products VALUES (@Name, @Price, @Calories, @Description);Select SCOPE_IDENTITY();";
            try
            {
                int ProID=-1;
                using (SqlConnection con = new SqlConnection(cnstring))
                {
                    con.Open();
                    using (SqlCommand cm = new SqlCommand(sqlquery, con))
                    {
                        cm.Parameters.AddWithValue("@Name", name);
                        cm.Parameters.AddWithValue("@Calories", Convert.ToInt32(calories));
                        cm.Parameters.AddWithValue("@Price", Convert.ToDouble(price));
                        cm.Parameters.AddWithValue("@Description", description);
                        object result = cm.ExecuteScalar();
                        if (result != null)
                        {
                            ProID = Convert.ToInt32(result);
                        }
                        
                    }
                    sqlquery = "Insert into MenuItems values(@ProID)";
                    using (SqlCommand cm = new SqlCommand(sqlquery, con))
                    {
                        cm.Parameters.AddWithValue("@ProID", ProID);
                        cm.ExecuteNonQuery();
                    }
                    sqlquery = "Insert into Inventories values(@ProID,@Quan)";
                    using (SqlCommand cm = new SqlCommand(sqlquery, con))
                    {
                        cm.Parameters.AddWithValue("@ProID", ProID);
                        cm.Parameters.AddWithValue("@Quan", 50);
                        cm.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Record inserted successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
