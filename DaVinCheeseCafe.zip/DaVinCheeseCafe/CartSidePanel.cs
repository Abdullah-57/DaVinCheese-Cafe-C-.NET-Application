﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DaVinCheeseCafe
{
    public partial class CartSidePanel : UserControl
    {

        public int activeID;
        public string total;
        public CartSidePanel()
        {
            
            InitializeComponent();
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            CreditCardScreen ccs = new CreditCardScreen();
            ccs.activeID = activeID;
            ccs.totalbill = int.Parse(total);
            ccs.Show();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OnlinePayments op = new OnlinePayments();
            op.activeID = activeID;
            op.totalbill = int.Parse(total);
            op.Show();

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
