﻿namespace DaVinCheeseCafe
{
    partial class ManagerLanding
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ManagerLanding));
            this.panel1 = new System.Windows.Forms.Panel();
            this.Inventorybtn = new System.Windows.Forms.Button();
            this.addEmployeeDetailBtn = new System.Windows.Forms.Button();
            this.addSpecialDiscountButton = new System.Windows.Forms.Button();
            this.changeproductinfobtn = new System.Windows.Forms.Button();
            this.viewSalesButton = new System.Windows.Forms.Button();
            this.addEmployeeButton = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.managerHome1 = new DaVinCheeseCafe.ManagerHome();
            this.addInventoryForm1 = new DaVinCheeseCafe.AddInventoryForm();
            this.addSpecialDiscountsForm1 = new DaVinCheeseCafe.AddSpecialDiscountsForm();
            this.editProductDetailsForm1 = new DaVinCheeseCafe.EditProductDetailsForm();
            this.editEmployeeDetail1 = new DaVinCheeseCafe.EditEmployeeDetail();
            this.viewSalesForm = new DaVinCheeseCafe.ViewSales();
            this.addEmployeeForm = new DaVinCheeseCafe.AddEmployee();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Firebrick;
            this.panel1.Controls.Add(this.Inventorybtn);
            this.panel1.Controls.Add(this.addEmployeeDetailBtn);
            this.panel1.Controls.Add(this.addSpecialDiscountButton);
            this.panel1.Controls.Add(this.changeproductinfobtn);
            this.panel1.Controls.Add(this.viewSalesButton);
            this.panel1.Controls.Add(this.addEmployeeButton);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(0, -1);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(513, 828);
            this.panel1.TabIndex = 0;
            // 
            // Inventorybtn
            // 
            this.Inventorybtn.BackColor = System.Drawing.Color.IndianRed;
            this.Inventorybtn.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.Inventorybtn.FlatAppearance.BorderSize = 3;
            this.Inventorybtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.Inventorybtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Inventorybtn.Font = new System.Drawing.Font("Perpetua Titling MT", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Inventorybtn.Location = new System.Drawing.Point(55, 726);
            this.Inventorybtn.Margin = new System.Windows.Forms.Padding(4);
            this.Inventorybtn.Name = "Inventorybtn";
            this.Inventorybtn.Size = new System.Drawing.Size(407, 64);
            this.Inventorybtn.TabIndex = 16;
            this.Inventorybtn.Text = "Add Inventory";
            this.Inventorybtn.UseVisualStyleBackColor = false;
            this.Inventorybtn.Click += new System.EventHandler(this.Inventorybtn_Click);
            // 
            // addEmployeeDetailBtn
            // 
            this.addEmployeeDetailBtn.BackColor = System.Drawing.Color.IndianRed;
            this.addEmployeeDetailBtn.FlatAppearance.BorderSize = 3;
            this.addEmployeeDetailBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.addEmployeeDetailBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addEmployeeDetailBtn.Font = new System.Drawing.Font("Perpetua Titling MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addEmployeeDetailBtn.Location = new System.Drawing.Point(55, 252);
            this.addEmployeeDetailBtn.Margin = new System.Windows.Forms.Padding(4);
            this.addEmployeeDetailBtn.Name = "addEmployeeDetailBtn";
            this.addEmployeeDetailBtn.Size = new System.Drawing.Size(407, 65);
            this.addEmployeeDetailBtn.TabIndex = 7;
            this.addEmployeeDetailBtn.Text = "View Employee Details";
            this.addEmployeeDetailBtn.UseVisualStyleBackColor = false;
            this.addEmployeeDetailBtn.Click += new System.EventHandler(this.addEmployeeDetailBtn_Click);
            // 
            // addSpecialDiscountButton
            // 
            this.addSpecialDiscountButton.BackColor = System.Drawing.Color.IndianRed;
            this.addSpecialDiscountButton.FlatAppearance.BorderSize = 3;
            this.addSpecialDiscountButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.addSpecialDiscountButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addSpecialDiscountButton.Font = new System.Drawing.Font("Perpetua Titling MT", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addSpecialDiscountButton.Location = new System.Drawing.Point(55, 601);
            this.addSpecialDiscountButton.Margin = new System.Windows.Forms.Padding(4);
            this.addSpecialDiscountButton.Name = "addSpecialDiscountButton";
            this.addSpecialDiscountButton.Size = new System.Drawing.Size(407, 69);
            this.addSpecialDiscountButton.TabIndex = 6;
            this.addSpecialDiscountButton.Text = "Add EVENT DISCOUNTS";
            this.addSpecialDiscountButton.UseVisualStyleBackColor = false;
            this.addSpecialDiscountButton.Click += new System.EventHandler(this.addSpecialDiscountButton_Click);
            // 
            // changeproductinfobtn
            // 
            this.changeproductinfobtn.BackColor = System.Drawing.Color.IndianRed;
            this.changeproductinfobtn.FlatAppearance.BorderSize = 3;
            this.changeproductinfobtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.changeproductinfobtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.changeproductinfobtn.Font = new System.Drawing.Font("Perpetua Titling MT", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.changeproductinfobtn.Location = new System.Drawing.Point(55, 480);
            this.changeproductinfobtn.Margin = new System.Windows.Forms.Padding(4);
            this.changeproductinfobtn.Name = "changeproductinfobtn";
            this.changeproductinfobtn.Size = new System.Drawing.Size(407, 69);
            this.changeproductinfobtn.TabIndex = 4;
            this.changeproductinfobtn.Text = "View Product Details";
            this.changeproductinfobtn.UseVisualStyleBackColor = false;
            this.changeproductinfobtn.Click += new System.EventHandler(this.changeproductinfobtn_Click);
            // 
            // viewSalesButton
            // 
            this.viewSalesButton.BackColor = System.Drawing.Color.IndianRed;
            this.viewSalesButton.FlatAppearance.BorderSize = 3;
            this.viewSalesButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.viewSalesButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.viewSalesButton.Font = new System.Drawing.Font("Perpetua Titling MT", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewSalesButton.Location = new System.Drawing.Point(55, 358);
            this.viewSalesButton.Margin = new System.Windows.Forms.Padding(4);
            this.viewSalesButton.Name = "viewSalesButton";
            this.viewSalesButton.Size = new System.Drawing.Size(407, 70);
            this.viewSalesButton.TabIndex = 3;
            this.viewSalesButton.Text = "VIEW SALES";
            this.viewSalesButton.UseVisualStyleBackColor = false;
            this.viewSalesButton.Click += new System.EventHandler(this.viewSalesButton_Click);
            // 
            // addEmployeeButton
            // 
            this.addEmployeeButton.BackColor = System.Drawing.Color.IndianRed;
            this.addEmployeeButton.FlatAppearance.BorderSize = 3;
            this.addEmployeeButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.addEmployeeButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addEmployeeButton.Font = new System.Drawing.Font("Perpetua Titling MT", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addEmployeeButton.Location = new System.Drawing.Point(55, 146);
            this.addEmployeeButton.Margin = new System.Windows.Forms.Padding(4);
            this.addEmployeeButton.Name = "addEmployeeButton";
            this.addEmployeeButton.Size = new System.Drawing.Size(407, 60);
            this.addEmployeeButton.TabIndex = 15;
            this.addEmployeeButton.Text = "ADD EMPLOYEE";
            this.addEmployeeButton.UseVisualStyleBackColor = false;
            this.addEmployeeButton.Click += new System.EventHandler(this.addEmployeeButton_Click);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.Firebrick;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Perpetua Titling MT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.SystemColors.Menu;
            this.textBox1.Location = new System.Drawing.Point(143, 47);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(319, 48);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = "Management";
            this.textBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.textBox1_MouseClick);
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(20, 7);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(116, 126);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.IndianRed;
            this.panel2.Controls.Add(this.managerHome1);
            this.panel2.Controls.Add(this.addInventoryForm1);
            this.panel2.Controls.Add(this.addSpecialDiscountsForm1);
            this.panel2.Controls.Add(this.editProductDetailsForm1);
            this.panel2.Controls.Add(this.editEmployeeDetail1);
            this.panel2.Controls.Add(this.viewSalesForm);
            this.panel2.Controls.Add(this.addEmployeeForm);
            this.panel2.Location = new System.Drawing.Point(509, 1);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1205, 826);
            this.panel2.TabIndex = 1;
            // 
            // managerHome1
            // 
            this.managerHome1.BackColor = System.Drawing.Color.IndianRed;
            this.managerHome1.Location = new System.Drawing.Point(0, -2);
            this.managerHome1.Margin = new System.Windows.Forms.Padding(4);
            this.managerHome1.Name = "managerHome1";
            this.managerHome1.Size = new System.Drawing.Size(1205, 828);
            this.managerHome1.TabIndex = 20;
            this.managerHome1.Visible = false;
            // 
            // addInventoryForm1
            // 
            this.addInventoryForm1.Location = new System.Drawing.Point(0, 5);
            this.addInventoryForm1.Margin = new System.Windows.Forms.Padding(4);
            this.addInventoryForm1.Name = "addInventoryForm1";
            this.addInventoryForm1.Size = new System.Drawing.Size(1201, 833);
            this.addInventoryForm1.TabIndex = 19;
            this.addInventoryForm1.Visible = false;
            // 
            // addSpecialDiscountsForm1
            // 
            this.addSpecialDiscountsForm1.Location = new System.Drawing.Point(0, -2);
            this.addSpecialDiscountsForm1.Margin = new System.Windows.Forms.Padding(4);
            this.addSpecialDiscountsForm1.Name = "addSpecialDiscountsForm1";
            this.addSpecialDiscountsForm1.Size = new System.Drawing.Size(1201, 822);
            this.addSpecialDiscountsForm1.TabIndex = 18;
            this.addSpecialDiscountsForm1.Visible = false;
            // 
            // editProductDetailsForm1
            // 
            this.editProductDetailsForm1.Location = new System.Drawing.Point(0, -2);
            this.editProductDetailsForm1.Margin = new System.Windows.Forms.Padding(4);
            this.editProductDetailsForm1.Name = "editProductDetailsForm1";
            this.editProductDetailsForm1.Size = new System.Drawing.Size(1201, 822);
            this.editProductDetailsForm1.TabIndex = 17;
            this.editProductDetailsForm1.Visible = false;
            // 
            // editEmployeeDetail1
            // 
            this.editEmployeeDetail1.Location = new System.Drawing.Point(4, 2);
            this.editEmployeeDetail1.Margin = new System.Windows.Forms.Padding(4);
            this.editEmployeeDetail1.Name = "editEmployeeDetail1";
            this.editEmployeeDetail1.Size = new System.Drawing.Size(1201, 822);
            this.editEmployeeDetail1.TabIndex = 17;
            this.editEmployeeDetail1.Visible = false;
            // 
            // viewSalesForm
            // 
            this.viewSalesForm.BackColor = System.Drawing.Color.IndianRed;
            this.viewSalesForm.Location = new System.Drawing.Point(0, -2);
            this.viewSalesForm.Margin = new System.Windows.Forms.Padding(4);
            this.viewSalesForm.Name = "viewSalesForm";
            this.viewSalesForm.Size = new System.Drawing.Size(1205, 822);
            this.viewSalesForm.TabIndex = 1;
            this.viewSalesForm.Visible = false;
            // 
            // addEmployeeForm
            // 
            this.addEmployeeForm.Location = new System.Drawing.Point(17, 235);
            this.addEmployeeForm.Margin = new System.Windows.Forms.Padding(4);
            this.addEmployeeForm.Name = "addEmployeeForm";
            this.addEmployeeForm.Size = new System.Drawing.Size(1184, 384);
            this.addEmployeeForm.TabIndex = 0;
            this.addEmployeeForm.Visible = false;
            // 
            // ManagerLanding
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1716, 830);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ManagerLanding";
            this.Text = "ManagerForm";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button addEmployeeButton;
        private System.Windows.Forms.Button addEmployeeDetailBtn;
        private System.Windows.Forms.Button addSpecialDiscountButton;
        private System.Windows.Forms.Button changeproductinfobtn;
        private System.Windows.Forms.Button viewSalesButton;
        private System.Windows.Forms.Button Inventorybtn;
        private System.Windows.Forms.Panel panel2;
        private AddEmployee addEmployeeForm;
        private ViewSales viewSalesForm;
        private EditEmployeeDetail editEmployeeDetail1;
        private EditProductDetailsForm editProductDetailsForm1;
        private AddSpecialDiscountsForm addSpecialDiscountsForm1;
        private AddInventoryForm addInventoryForm1;
        private ManagerHome managerHome1;
    }
}