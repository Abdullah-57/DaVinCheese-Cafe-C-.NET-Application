﻿namespace DaVinCheeseCafe
{
    partial class CustomerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CustomerForm));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.ProfileBtn = new System.Windows.Forms.Button();
            this.CartBtn = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.Label();
            this.Ordermade = new System.Windows.Forms.Label();
            this.name = new System.Windows.Forms.Label();
            this.contact = new System.Windows.Forms.Label();
            this.emailtxt = new System.Windows.Forms.Label();
            this.contacttxt = new System.Windows.Forms.Label();
            this.nametxt = new System.Windows.Forms.Label();
            this.ordermadetxt = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.pastOrders1 = new DaVinCheeseCafe.PastOrders();
            this.menuItems1 = new DaVinCheeseCafe.MenuItems();
            this.cart1 = new DaVinCheeseCafe.Cart();
            this.reservationForm1 = new DaVinCheeseCafe.ReservationForm();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(0, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(120, 133);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Perpetua Titling MT", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(126, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(281, 52);
            this.label1.TabIndex = 1;
            this.label1.Text = "HOMEPAGE";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Firebrick;
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.ProfileBtn);
            this.panel1.Controls.Add(this.CartBtn);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(3, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(475, 1012);
            this.panel1.TabIndex = 2;
            // 
            // ProfileBtn
            // 
            this.ProfileBtn.BackColor = System.Drawing.Color.IndianRed;
            this.ProfileBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ProfileBtn.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.ProfileBtn.FlatAppearance.BorderSize = 3;
            this.ProfileBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.ProfileBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ProfileBtn.Font = new System.Drawing.Font("Perpetua Titling MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProfileBtn.Image = ((System.Drawing.Image)(resources.GetObject("ProfileBtn.Image")));
            this.ProfileBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ProfileBtn.Location = new System.Drawing.Point(48, 457);
            this.ProfileBtn.Name = "ProfileBtn";
            this.ProfileBtn.Size = new System.Drawing.Size(364, 86);
            this.ProfileBtn.TabIndex = 17;
            this.ProfileBtn.Text = "Profile";
            this.ProfileBtn.UseVisualStyleBackColor = false;
            this.ProfileBtn.Click += new System.EventHandler(this.ProfileBtn_Click);
            // 
            // CartBtn
            // 
            this.CartBtn.BackColor = System.Drawing.Color.IndianRed;
            this.CartBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.CartBtn.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.CartBtn.FlatAppearance.BorderSize = 3;
            this.CartBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.CartBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.CartBtn.Font = new System.Drawing.Font("Perpetua Titling MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CartBtn.Image = ((System.Drawing.Image)(resources.GetObject("CartBtn.Image")));
            this.CartBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.CartBtn.Location = new System.Drawing.Point(48, 348);
            this.CartBtn.Name = "CartBtn";
            this.CartBtn.Size = new System.Drawing.Size(364, 86);
            this.CartBtn.TabIndex = 16;
            this.CartBtn.Text = "CART";
            this.CartBtn.UseVisualStyleBackColor = false;
            this.CartBtn.Click += new System.EventHandler(this.CartBtn_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.IndianRed;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button3.FlatAppearance.BorderSize = 3;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Perpetua Titling MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(48, 142);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(364, 86);
            this.button3.TabIndex = 15;
            this.button3.Text = "MENU";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.IndianRed;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button2.FlatAppearance.BorderSize = 3;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Perpetua Titling MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(48, 244);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(364, 86);
            this.button2.TabIndex = 14;
            this.button2.Text = "RESERVATION";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.ReservationBtn_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.IndianRed;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button1.FlatAppearance.BorderSize = 3;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Perpetua Titling MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(48, 689);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(364, 86);
            this.button1.TabIndex = 13;
            this.button1.Text = "SIGN OUT";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(0, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 23);
            this.label7.TabIndex = 0;
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.email.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.email.Font = new System.Drawing.Font("Perpetua Titling MT", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email.ForeColor = System.Drawing.Color.Maroon;
            this.email.Location = new System.Drawing.Point(636, 102);
            this.email.Name = "email";
            this.email.Padding = new System.Windows.Forms.Padding(10);
            this.email.Size = new System.Drawing.Size(146, 55);
            this.email.TabIndex = 3;
            this.email.Text = "EMAIL :";
            this.email.Visible = false;
            // 
            // Ordermade
            // 
            this.Ordermade.AutoSize = true;
            this.Ordermade.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Ordermade.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Ordermade.Font = new System.Drawing.Font("Perpetua Titling MT", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ordermade.ForeColor = System.Drawing.Color.Maroon;
            this.Ordermade.Location = new System.Drawing.Point(636, 455);
            this.Ordermade.Name = "Ordermade";
            this.Ordermade.Padding = new System.Windows.Forms.Padding(10);
            this.Ordermade.Size = new System.Drawing.Size(274, 55);
            this.Ordermade.TabIndex = 4;
            this.Ordermade.Text = "ORDERS MADE :";
            this.Ordermade.Visible = false;
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.name.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.name.Font = new System.Drawing.Font("Perpetua Titling MT", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.ForeColor = System.Drawing.Color.Maroon;
            this.name.Location = new System.Drawing.Point(636, 331);
            this.name.Name = "name";
            this.name.Padding = new System.Windows.Forms.Padding(10);
            this.name.Size = new System.Drawing.Size(143, 55);
            this.name.TabIndex = 6;
            this.name.Text = "NAME :";
            this.name.Visible = false;
            // 
            // contact
            // 
            this.contact.AutoSize = true;
            this.contact.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.contact.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.contact.Font = new System.Drawing.Font("Perpetua Titling MT", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contact.ForeColor = System.Drawing.Color.Maroon;
            this.contact.Location = new System.Drawing.Point(636, 209);
            this.contact.Name = "contact";
            this.contact.Padding = new System.Windows.Forms.Padding(10);
            this.contact.Size = new System.Drawing.Size(201, 55);
            this.contact.TabIndex = 7;
            this.contact.Text = "CONTACT :";
            this.contact.Visible = false;
            // 
            // emailtxt
            // 
            this.emailtxt.AutoSize = true;
            this.emailtxt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.emailtxt.Font = new System.Drawing.Font("Perpetua Titling MT", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailtxt.ForeColor = System.Drawing.Color.Black;
            this.emailtxt.Location = new System.Drawing.Point(817, 102);
            this.emailtxt.Name = "emailtxt";
            this.emailtxt.Padding = new System.Windows.Forms.Padding(10);
            this.emailtxt.Size = new System.Drawing.Size(144, 53);
            this.emailtxt.TabIndex = 8;
            this.emailtxt.Text = "EMAIL :";
            this.emailtxt.Visible = false;
            // 
            // contacttxt
            // 
            this.contacttxt.AutoSize = true;
            this.contacttxt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.contacttxt.Font = new System.Drawing.Font("Perpetua Titling MT", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contacttxt.ForeColor = System.Drawing.Color.Black;
            this.contacttxt.Location = new System.Drawing.Point(882, 209);
            this.contacttxt.Name = "contacttxt";
            this.contacttxt.Padding = new System.Windows.Forms.Padding(10);
            this.contacttxt.Size = new System.Drawing.Size(199, 53);
            this.contacttxt.TabIndex = 9;
            this.contacttxt.Text = "CONTACT :";
            this.contacttxt.Visible = false;
            // 
            // nametxt
            // 
            this.nametxt.AutoSize = true;
            this.nametxt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.nametxt.Font = new System.Drawing.Font("Perpetua Titling MT", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nametxt.ForeColor = System.Drawing.Color.Black;
            this.nametxt.Location = new System.Drawing.Point(817, 331);
            this.nametxt.Name = "nametxt";
            this.nametxt.Padding = new System.Windows.Forms.Padding(10);
            this.nametxt.Size = new System.Drawing.Size(141, 53);
            this.nametxt.TabIndex = 10;
            this.nametxt.Text = "NAME :";
            this.nametxt.Visible = false;
            // 
            // ordermadetxt
            // 
            this.ordermadetxt.AutoSize = true;
            this.ordermadetxt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ordermadetxt.Font = new System.Drawing.Font("Perpetua Titling MT", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ordermadetxt.ForeColor = System.Drawing.Color.Black;
            this.ordermadetxt.Location = new System.Drawing.Point(943, 455);
            this.ordermadetxt.Name = "ordermadetxt";
            this.ordermadetxt.Padding = new System.Windows.Forms.Padding(10);
            this.ordermadetxt.Size = new System.Drawing.Size(272, 53);
            this.ordermadetxt.TabIndex = 11;
            this.ordermadetxt.Text = "ORDERS MADE :";
            this.ordermadetxt.Visible = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.IndianRed;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button4.FlatAppearance.BorderSize = 3;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Perpetua Titling MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(48, 571);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(364, 86);
            this.button4.TabIndex = 18;
            this.button4.Text = "Past Orders";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // pastOrders1
            // 
            this.pastOrders1.BackColor = System.Drawing.Color.RosyBrown;
            this.pastOrders1.Location = new System.Drawing.Point(476, 1);
            this.pastOrders1.Name = "pastOrders1";
            this.pastOrders1.Size = new System.Drawing.Size(1244, 840);
            this.pastOrders1.TabIndex = 15;
            this.pastOrders1.Visible = false;
            // 
            // menuItems1
            // 
            this.menuItems1.BackColor = System.Drawing.Color.DarkSalmon;
            this.menuItems1.Location = new System.Drawing.Point(476, -2);
            this.menuItems1.Name = "menuItems1";
            this.menuItems1.Size = new System.Drawing.Size(1717, 1025);
            this.menuItems1.TabIndex = 14;
            this.menuItems1.Visible = false;
            this.menuItems1.Load += new System.EventHandler(this.menuItems1_Load);
            // 
            // cart1
            // 
            this.cart1.BackColor = System.Drawing.Color.DarkSalmon;
            this.cart1.Location = new System.Drawing.Point(476, -16);
            this.cart1.Name = "cart1";
            this.cart1.Size = new System.Drawing.Size(1197, 869);
            this.cart1.TabIndex = 13;
            this.cart1.Visible = false;
            // 
            // reservationForm1
            // 
            this.reservationForm1.BackColor = System.Drawing.Color.DarkSalmon;
            this.reservationForm1.Location = new System.Drawing.Point(476, -2);
            this.reservationForm1.Name = "reservationForm1";
            this.reservationForm1.Size = new System.Drawing.Size(1107, 843);
            this.reservationForm1.TabIndex = 12;
            this.reservationForm1.Visible = false;
            this.reservationForm1.Load += new System.EventHandler(this.reservationForm1_Load);
            // 
            // CustomerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RosyBrown;
            this.ClientSize = new System.Drawing.Size(1716, 829);
            this.Controls.Add(this.pastOrders1);
            this.Controls.Add(this.menuItems1);
            this.Controls.Add(this.cart1);
            this.Controls.Add(this.reservationForm1);
            this.Controls.Add(this.ordermadetxt);
            this.Controls.Add(this.nametxt);
            this.Controls.Add(this.contacttxt);
            this.Controls.Add(this.emailtxt);
            this.Controls.Add(this.contact);
            this.Controls.Add(this.name);
            this.Controls.Add(this.Ordermade);
            this.Controls.Add(this.email);
            this.Controls.Add(this.panel1);
            this.Name = "CustomerForm";
            this.Text = "CustomerLanding";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button ProfileBtn;
        private System.Windows.Forms.Button CartBtn;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.Label Ordermade;
        private System.Windows.Forms.Label name;
        private System.Windows.Forms.Label contact;
        private System.Windows.Forms.Label emailtxt;
        private System.Windows.Forms.Label contacttxt;
        private System.Windows.Forms.Label nametxt;
        private System.Windows.Forms.Label ordermadetxt;
        private ReservationForm reservationForm1;
        private Cart cart1;
        private MenuItems menuItems1;
        private System.Windows.Forms.Button button4;
        private PastOrders pastOrders1;
    }
}