﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DaVinCheeseCafe
{
    
    public partial class PastOrders : UserControl
    {
        public int activeID;
        public PastOrders()
        {
            InitializeComponent();
        }

        public void PopulateGrid() 
        {
            string cnstring = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";
            string sqlquery = "select I.InvoiceTime,I.InvoiceDate,I.Amount from Invoices I where CustomerID=(Select CustomerID from Customers where UserID=@UserID);";
            try
            {
                using (SqlConnection cn = new SqlConnection(cnstring))
                {
                    using (SqlCommand cmd = new SqlCommand(sqlquery, cn))
                    {
                        cmd.Parameters.AddWithValue("@UserID", activeID);
                        cn.Open();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dataGridView1.DataSource = dt;
                        
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void PastOrders_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
