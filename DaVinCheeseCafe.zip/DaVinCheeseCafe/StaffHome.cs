﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DaVinCheeseCafe
{
    public partial class StaffHome : UserControl
    {
        public int activeID;
        public StaffHome()
        {
            InitializeComponent();
        }
        public void FetchStaffData()
        {

            string sqlQuery = "SELECT U.FirstName, U.LastName,U.ContactNo,U.Password,U.Email FROM Staff M JOIN Users U ON M.UserID = U.UserID; ";

            string cnString = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";
            SqlConnection cn = new SqlConnection(cnString);
            SqlCommand cmd = new SqlCommand(sqlQuery, cn);
            cn.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {

                label2.Text = "MR. " + dr["FirstName"].ToString() + " " + dr["LastName"].ToString();
                label9.Text = dr["ContactNo"].ToString();
                label8.Text = dr["Password"].ToString();
                label7.Text = dr["Email"].ToString();

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
    }
}
