﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DaVinCheeseCafe
{
    public partial class ReservationsViewer : UserControl
    {
        public ReservationsViewer()
        {
            InitializeComponent();
        }
        public void ShowReservations() 
        {
            dataGridView1.Rows.Clear();
            if (string.IsNullOrEmpty(textBox2.Text))
            {
                return;
            }
            int CustomerID= Convert.ToInt32(textBox2.Text);
            string cnstring = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";
            if (string.IsNullOrEmpty(textBox1.Text)) 
            {
                return;
            }
            int reservationcount=Convert.ToInt32( textBox1.Text);

           
           string sqlquery = "select ReservationID,TableNo,SUM(ReservationID)as TotalReservation from Reservations where CustomerActionID IN(select CustomerActionID from CustomerActions where CustomerID=@CustomerID) group by ReservationID,TableNo having SUM(ReservationID)=@Counts;";
            using (SqlConnection cn = new SqlConnection(cnstring))
            {
                cn.Open();
                using (SqlCommand cmd = new SqlCommand(sqlquery, cn))
                {
                    cmd.Parameters.AddWithValue("@CustomerID", CustomerID);
                    cmd.Parameters.AddWithValue("@Counts", reservationcount);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            dataGridView1.Rows.Add(CustomerID,dr["ReservationID"].ToString(), dr["TableNo"].ToString());
                        }
                    }
                }
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            ShowReservations();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
