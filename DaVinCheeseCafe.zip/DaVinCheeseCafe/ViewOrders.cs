﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DaVinCheeseCafe
{
    public partial class ViewOrders : UserControl
    {
        public ViewOrders()
        {
            InitializeComponent();
        }
        public void FetchOrders()
        {
            dataGridView1.Rows.Clear();
            int counts=0;
            if (!string.IsNullOrEmpty(textBox1.Text)) 
            {
            counts=Convert.ToInt32(textBox1.Text);
            }
            string sqlquery = "SELECT C.CustomerID, CONCAT(U.FirstName, ' ', U.LastName) AS CustomerName, COUNT(*) AS TotalOrders FROM Customers C JOIN Users U ON C.UserID = U.UserID JOIN   Invoices I ON C.CustomerID = I.CustomerID JOIN  Sales S ON I.InvoiceID = S.InvoiceID GROUP BY C.CustomerID, U.FirstName, U.LastName HAVING COUNT(*) = @counts;";
            string cnstring = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";
            try
            {
                using (SqlConnection con = new SqlConnection(cnstring))
                {
                    con.Open();
                    using (SqlCommand cm = new SqlCommand(sqlquery, con))
                    {
                        cm.Parameters.AddWithValue("@counts", counts);
                        SqlDataReader dr = cm.ExecuteReader();
                        while (dr.Read())
                        {
                            dataGridView1.Rows.Add(dr[0], dr[1], dr[2]);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            FetchOrders();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
  
}
