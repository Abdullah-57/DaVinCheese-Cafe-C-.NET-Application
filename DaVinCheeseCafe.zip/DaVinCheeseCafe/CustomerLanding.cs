﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DaVinCheeseCafe
{

    public partial class CustomerForm : Form
    {
       public int activeID;
        public CustomerForm(int id)
        {
            InitializeComponent();
            activeID = id;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Close();
        }

        private bool profileVisible = false;
        private bool RformVisible = false;
        private void ProfileBtn_Click(object sender, EventArgs e)
        {
            if (profileVisible == true) 
            {
                profileVisible = false; 
            ProfileBtn.BackColor = Color.IndianRed;
                this.BackColor = Color.RosyBrown;
            }
            else 
            {
                profileVisible = true;

                ProfileBtn.BackColor = Color.Firebrick;
                this.BackColor = Color.DarkSalmon;
            } 

            email.Visible = profileVisible;
            contact.Visible = profileVisible;
            Ordermade.Visible = profileVisible;
            name.Visible = profileVisible;
            nametxt.Visible = profileVisible;
            emailtxt.Visible = profileVisible;
            contacttxt.Visible = profileVisible;
            ordermadetxt.Visible = profileVisible;

            if (profileVisible)
            {
                string cnstring = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";
                string sqlquery = "SELECT FirstName, LastName, Email, ContactNo FROM Users WHERE UserID = @UserID;";
                try
                {
                    using (SqlConnection con = new SqlConnection(cnstring))
                    {
                        con.Open();
                        using (SqlCommand cm = new SqlCommand(sqlquery, con))
                        {
                            cm.Parameters.AddWithValue("@UserID", activeID);
                            using (SqlDataReader dr = cm.ExecuteReader())
                            {
                                if (dr.Read())
                                {
                                    nametxt.Text = dr["FirstName"].ToString() + " " + dr["LastName"].ToString();
                                    emailtxt.Text = dr["Email"].ToString();
                                    contacttxt.Text = dr["ContactNo"].ToString();
                                }
                            }
                        }

                        sqlquery = "SELECT COUNT(*) FROM Invoices I JOIN Customers C ON C.CustomerID = I.CustomerID WHERE C.UserID = @UserID;";
                        using (SqlCommand cm = new SqlCommand(sqlquery, con))
                        {
                            cm.Parameters.AddWithValue("@UserID", activeID);
                            object result = cm.ExecuteScalar();
                            if (result != null)
                            {
                                ordermadetxt.Text = result.ToString();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }

        private void ReservationBtn_Click(object sender, EventArgs e)
        {

            reservationForm1.userID = activeID;
            if (RformVisible == true)
            {
                reservationForm1.Visible = false;
                RformVisible = false;
                button2.BackColor = Color.IndianRed;
                this.BackColor = Color.RosyBrown;
            }
            else
            {
                RformVisible = true;
                reservationForm1.Visible = true;
                button2.BackColor = Color.Firebrick;
                this.BackColor = Color.DarkSalmon;
            }
        }


        private void reservationForm1_Load(object sender, EventArgs e)
        {

        }
        private bool cartform = false;
        private void CartBtn_Click(object sender, EventArgs e)
        {

            cart1.userID = activeID;
          
            if (cartform == true)
            {
                cartform = false;
                cart1.Visible = false;
                CartBtn.BackColor = Color.IndianRed;
                this.BackColor = Color.RosyBrown;
            }
            else
            {
                cartform = true;
                cart1.Visible = true;
                CartBtn.BackColor = Color.Firebrick;
                this.BackColor = Color.DarkSalmon;
                cart1.DisplayCart();
            }
        }
        private bool menuform = false;
        private void button3_Click(object sender, EventArgs e)
        {
           menuItems1.UserID = activeID;
            if (menuform== true)
            {
                menuform = false;
                menuItems1.Visible = false;
                button3.BackColor = Color.IndianRed;
                this.BackColor = Color.RosyBrown;
            }
            else
            {
                menuform = true;
                menuItems1.Visible = true;
                menuItems1.PopulateMenuGrid();
                button3.BackColor = Color.Firebrick;
                this.BackColor = Color.DarkSalmon;
                
            }
        }

        private void menuItems1_Load(object sender, EventArgs e)
        {

        }
        bool ordertrigger = false;
        private void button4_Click(object sender, EventArgs e)
        {
            pastOrders1.activeID = activeID;
            if (ordertrigger == true)
            {
                ordertrigger = false;
                pastOrders1.Visible = false;
                button3.BackColor = Color.IndianRed;
                this.BackColor = Color.RosyBrown;
            }
            else
            {
                ordertrigger = true;
                pastOrders1.Visible = true;
                pastOrders1.PopulateGrid();
                button3.BackColor = Color.Firebrick;
                this.BackColor = Color.DarkSalmon;

            }
        }
    }
}
