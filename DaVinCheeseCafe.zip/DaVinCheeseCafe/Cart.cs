﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DaVinCheeseCafe
{
    public partial class Cart : UserControl
    {
        public int userID;
        public int totalbill = 0;

        public Cart()
        {
            InitializeComponent();
        }

        public void DisplayCart()
        {
            dataGridView1.Rows.Clear();
            try
            {
                string connectionString = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";

                string cartIdQuery = "SELECT Cu.CartID FROM Users U JOIN Customers Cu ON U.UserID = Cu.UserID WHERE U.UserID = @UserID;";

                int cartId;
                using (SqlConnection conCartID = new SqlConnection(connectionString))
                {
                    conCartID.Open();
                    using (SqlCommand cmdCartID = new SqlCommand(cartIdQuery, conCartID))
                    {
                        cmdCartID.Parameters.AddWithValue("@UserID", userID);
                        cartId = (int)cmdCartID.ExecuteScalar();

                        string cartItemsQuery = "SELECT Ci.MenuItemID, Ci.Qty FROM CartItems Ci WHERE Ci.CartID = @CartID;";
                        using (SqlConnection conCartItems = new SqlConnection(connectionString))
                        {
                            conCartItems.Open();
                            using (SqlCommand cmdCartItems = new SqlCommand(cartItemsQuery, conCartItems))
                            {
                                cmdCartItems.Parameters.AddWithValue("@CartID", cartId);

                                SqlDataReader cartItemsReader = cmdCartItems.ExecuteReader();

                                if (!cartItemsReader.HasRows)
                                {
                                    MessageBox.Show("Your cart is empty.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    return;
                                }

                                dataGridView1.Rows.Clear();

                                while (cartItemsReader.Read())
                                {
                                    int menuItemID = (int)cartItemsReader["MenuItemID"];
                                    int quantity = (int)cartItemsReader["Qty"];

                                    string itemDetailsQuery = "SELECT Mi.MenuItemID, P.Name, P.Price FROM MenuItems Mi JOIN Products P ON Mi.ProductID = P.ProductID WHERE Mi.MenuItemID = @MenuItemID;";
                                    using (SqlConnection conItemDetails = new SqlConnection(connectionString))
                                    {
                                        conItemDetails.Open();
                                        using (SqlCommand cmdItemDetails = new SqlCommand(itemDetailsQuery, conItemDetails))
                                        {
                                            cmdItemDetails.Parameters.AddWithValue("@MenuItemID", menuItemID);
                                            SqlDataReader itemDetailsReader = cmdItemDetails.ExecuteReader();

                                            if (itemDetailsReader.Read())
                                            {
                                                string name = itemDetailsReader["Name"].ToString();
                                                int price = (int)itemDetailsReader["Price"];

                                                dataGridView1.Rows.Add(name, price, quantity);
                                            }

                                            itemDetailsReader.Close();
                                        }
                                    }
                                }

                                cartItemsReader.Close();
                            }
                        }
                    }
                }

                string sqlquery = "SELECT SUM(P.Price * Ci.Qty) AS TotalBill FROM Carts C JOIN CartItems Ci ON C.CartID = Ci.CartID JOIN MenuItems Mi ON Ci.MenuItemID = Mi.MenuItemID JOIN Products P ON Mi.ProductID = P.ProductID WHERE C.CartID = @CartID;";
                using (SqlConnection conTotalBill = new SqlConnection(connectionString))
                {
                    conTotalBill.Open();
                    using (SqlCommand cmdTotalBill = new SqlCommand(sqlquery, conTotalBill))
                    {
                        cmdTotalBill.Parameters.AddWithValue("@CartID", cartId);
                        totalbill = (int)cmdTotalBill.ExecuteScalar();
                    }
                }

                label2.Text = "PKR " + totalbill.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            cartSidePanel1.total = totalbill.ToString();
            cartSidePanel1.Visible = true;
            cartSidePanel1.activeID = userID;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
