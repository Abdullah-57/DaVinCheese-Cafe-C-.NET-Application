﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DaVinCheeseCafe
{
    public partial class CreditCardScreen : Form
    {
        public int activeID;
        public int totalbill;
        public CreditCardScreen()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string cnstring = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESSet;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";
            string sqlquery = "INSERT INTO Invoices VALUES(CONVERT(time, GETDATE()), GETDATE(), @Amount, @CustomerID, @CartID); SELECT SCOPE_IDENTITY();";
            int cartID;
            int customerID;
            string cartQuery = "SELECT CartID FROM Customers WHERE Customers.UserID=@UserID;";

            using (SqlConnection connection = new SqlConnection(cnstring))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(cartQuery, connection);
                command.Parameters.AddWithValue("@UserID", activeID);
                cartID = (int)command.ExecuteScalar();
            }
            string customerQuery = "SELECT CustomerID FROM Customers WHERE Customers.UserID=@UserID;";

            using (SqlConnection connection = new SqlConnection(cnstring))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(customerQuery, connection);
                command.Parameters.AddWithValue("@UserID", activeID);
                customerID = (int)command.ExecuteScalar();
            }
            int invoiceid;
            using (SqlConnection connection = new SqlConnection(cnstring))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sqlquery, connection);
                command.Parameters.AddWithValue("@Amount", totalbill);
                command.Parameters.AddWithValue("@CustomerID", customerID);
                command.Parameters.AddWithValue("@CartID", cartID);
                invoiceid = Convert.ToInt32(command.ExecuteScalar());
            }
            sqlquery = "INSERT INTO Sales VALUES(@InvoiceID)";
            using (SqlConnection connection = new SqlConnection(cnstring))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sqlquery, connection);
                command.Parameters.AddWithValue("@InvoiceID", invoiceid);
                command.ExecuteNonQuery();
            }
            sqlquery = "INSERT INTO Payments VALUES(@Method, @Discount, @InvoiceID)";
            using (SqlConnection connection = new SqlConnection(cnstring))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sqlquery, connection);
                command.Parameters.AddWithValue("@Method", "CreditCard");
                command.Parameters.AddWithValue("@Discount", 0);
                command.Parameters.AddWithValue("@InvoiceID", invoiceid);
                command.ExecuteNonQuery();
            }
            

            sqlquery = "DELETE FROM CartItems WHERE CartID=@CartID;";
            using (SqlConnection connection = new SqlConnection(cnstring))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sqlquery, connection);
                command.Parameters.AddWithValue("@CartID", cartID);
                command.ExecuteNonQuery();
            }
            
            MessageBox.Show("Payment Successful");
        }

    }
}
