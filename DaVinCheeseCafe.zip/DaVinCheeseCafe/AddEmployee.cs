﻿using System;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;

namespace DaVinCheeseCafe
{
    public partial class AddEmployee : UserControl
    {
        public AddEmployee()
        {
            InitializeComponent();
        }
        public static bool Finder(string line, string tag)
        {
            for (int i = 0; i < line.Length; i++)
            {
                if (line[i] == tag[0])
                {
                    bool match = true;

                    for (int j = 0; j < tag.Length; j++)
                    {
                        if (i + j >= line.Length || line[i + j] != tag[j])
                        {
                            match = false;
                            break;
                        }
                    }
                    if (match)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        private void button1_Click(object sender, EventArgs e)
        {

            string email, pass, fname, lname;
            email = textBox3.Text;
            pass = textBox1.Text;
            fname = textBox4.Text;
            lname = textBox2.Text;
            string contactnum = textBox5.Text;

            if (string.IsNullOrWhiteSpace(email) || !Finder(email,"@gmail.com"))
            {
                MessageBox.Show("Please Enter a valid Email ending with @gmail.com", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (string.IsNullOrWhiteSpace(fname))
            {
                MessageBox.Show("Please Enter a valid FirstName", "Invalid FirstName", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (string.IsNullOrWhiteSpace(lname))
            {
                MessageBox.Show("Please Enter a valid LastName", "Invalid LastName", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (pass.Length < 8 || !pass.Any(char.IsUpper) || !pass.Any(char.IsLower) || !(pass.Any(char.IsDigit) || pass.Any(char.IsPunctuation)))
            {
                MessageBox.Show("Please Enter a Password with length greater than 8, containing both uppercase and lowercase letters, and at least one number or special character", "Weak Password", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            



            if (string.IsNullOrWhiteSpace(contactnum) || contactnum.Length != 11)
            {
                MessageBox.Show("Please Enter a valid ContactNum", "Invalid ContactNum", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            string cnstring = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";

            string sqlquery = "INSERT INTO Users (FirstName, LastName, Email, Password, ContactNo) VALUES (@FirstName, @LastName, @Email, @Password, @ContactNo);SELECT SCOPE_IDENTITY();";
            try
            {
                using (SqlConnection con = new SqlConnection(cnstring))
                {
                    con.Open();
                    int userid = 0;
                    using (SqlCommand cm = new SqlCommand(sqlquery, con))
                    {
                        cm.Parameters.AddWithValue("@FirstName", fname);
                        cm.Parameters.AddWithValue("@LastName", lname);
                        cm.Parameters.AddWithValue("@Email", email);
                        cm.Parameters.AddWithValue("@Password", pass);
                        cm.Parameters.AddWithValue("@ContactNo", contactnum);
                        userid = Convert.ToInt32(cm.ExecuteScalar());
                    }



                    sqlquery = "INSERT INTO Staff  VALUES (0, @UserID, 1)";
                    using (SqlCommand cm = new SqlCommand(sqlquery, con))
                    {
                        cm.Parameters.AddWithValue("@UserID", userid);

                        cm.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Record inserted successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            textBox5.Text = "";
            textBox4.Text = "";
            textBox3.Text = "";
            textBox2.Text = "";
            textBox1.Text = "";



        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
