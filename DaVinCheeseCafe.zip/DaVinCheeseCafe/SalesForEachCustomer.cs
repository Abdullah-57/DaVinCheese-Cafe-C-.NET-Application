﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DaVinCheeseCafe
{
    public partial class SalesForEachCustomer : UserControl
    {
        public SalesForEachCustomer()
        {
            InitializeComponent();
        }

        public void FetchAllSales()
        {
            dataGridView1.Rows.Clear();
            if (string.IsNullOrEmpty(textBox1.Text)) 
            {
                return;
            }
        int threshold = Convert.ToInt32(textBox1.Text);
            string sqlquery = "SELECT C.CustomerID, U.FirstName, U.LastName, SUM(I.Amount) AS TotalSalesAmount FROM Invoices AS I JOIN Customers AS C ON I.CustomerID = C.CustomerID JOIN Users AS U ON C.UserID = U.UserID GROUP BY C.CustomerID, U.FirstName, U.LastName Having SUM(I.Amount)>@threshold;";

            string cnstring = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";

            using (SqlConnection con = new SqlConnection(cnstring))
            {
                con.Open();
                using (SqlCommand cm = new SqlCommand(sqlquery, con))
                {
                    cm.Parameters.AddWithValue("@threshold", threshold);
                    using (SqlDataReader da = cm.ExecuteReader())
                    {
                        while (da.Read())
                        {
                            dataGridView1.Rows.Add(da["CustomerID"], da["FirstName"], da["LastName"], da["TotalSalesAmount"]);
                        }
                    }
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            FetchAllSales();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
