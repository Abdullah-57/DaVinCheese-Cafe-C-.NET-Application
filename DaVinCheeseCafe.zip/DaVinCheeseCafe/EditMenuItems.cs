﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DaVinCheeseCafe
{
    public partial class EditMenuItems : UserControl
    {
        public EditMenuItems()
        {
            InitializeComponent();
        }
        public void GetAllProducts()
        {
            dataGridView1.Rows.Clear();
            string sqlquery = "SELECT P.Name AS ProductName, P.Price, P.Calories, P.Description, I.Quantity AS InventoryQuantity FROM Products P JOIN MenuItems MI ON P.ProductID = MI.ProductID JOIN Inventories I ON P.ProductID = I.ProductID;";
            string cnstring = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";
            try
            {
                using (SqlConnection con = new SqlConnection(cnstring))
                {
                    con.Open();
                    using (SqlCommand cm = new SqlCommand(sqlquery, con))
                    {
                        SqlDataReader dr = cm.ExecuteReader();
                        while (dr.Read())
                        {
                            dataGridView1.Rows.Add(dr["ProductName"].ToString(), dr["Price"].ToString(), dr["Calories"].ToString(), dr["Description"].ToString(), dr["InventoryQuantity"].ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                textBox5.Text = row.Cells["ProductName"].Value.ToString();
                textBox4.Text = row.Cells["Price"].Value.ToString();
                textBox2.Text = row.Cells["Description"].Value.ToString();
                textBox3.Text = row.Cells["Calories"].Value.ToString();
            }
        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string productName = textBox5.Text;
            decimal price = Convert.ToDecimal(textBox4.Text);
            int calories = Convert.ToInt32(textBox3.Text);



            string description = textBox2.Text;

            string updateQuery = "UPDATE Products  SET Price = @Price, Calories = @Calories, Description = @Description WHERE Name = @ProductName";

            string cnstring = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";

            try
            {
                using (SqlConnection con = new SqlConnection(cnstring))
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(updateQuery, con))
                    {
                        cmd.Parameters.AddWithValue("@Price", price);
                        cmd.Parameters.AddWithValue("@Calories", calories);
                        cmd.Parameters.AddWithValue("@Description", description);
                        cmd.Parameters.AddWithValue("@ProductName", productName);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Product updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            GetAllProducts();
                        }
                        else
                        {
                            MessageBox.Show("No product found with the given name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


    }
}
