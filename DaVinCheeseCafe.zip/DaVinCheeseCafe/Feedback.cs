﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DaVinCheeseCafe
{
    public partial class Feedback : UserControl
    {
        public int userID;
        public int itemID;
        public Feedback()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int CustomerID = 0;
            string cnstring = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";
            string sqlquery = "select Customers.CustomerID from Customers where Customers.UserID=@UserID;";

            try
            {
                using (SqlConnection con = new SqlConnection(cnstring))
                {
                    con.Open();
                    using (SqlCommand cm = new SqlCommand(sqlquery, con))
                    {
                        cm.Parameters.AddWithValue("@UserID", userID);
                        object result = cm.ExecuteScalar();
                        if (result != null)
                        {
                            CustomerID = Convert.ToInt32(result);
                        }
                    }

                    sqlquery = "INSERT INTO CustomerActions (CustomerID, ActionDate, ActionTime) VALUES (@CustomerID, GETDATE(), CONVERT(time, GETDATE())); SELECT SCOPE_IDENTITY();";
                    int customerActionID=0;
                    using (SqlCommand cm = new SqlCommand(sqlquery, con))
                    {

                        cm.Parameters.AddWithValue("@CustomerID", CustomerID);
                        object result = cm.ExecuteScalar();
                        if (result != null)
                        {
                            customerActionID = Convert.ToInt32(result);
                        }

                    }

                    sqlquery = "INSERT INTO Feedbacks VALUES (@Remarks,@CustomerActionID);SELECT SCOPE_IDENTITY();";
                 int feedbackID=0;
                    using (SqlCommand cm = new SqlCommand(sqlquery, con))
                    {
                        cm.Parameters.AddWithValue("@Remarks", textBox1.Text);
                        cm.Parameters.AddWithValue("@CustomerActionID", customerActionID);
                        object result = cm.ExecuteScalar();
                        if (result != null)
                        {
                            feedbackID = Convert.ToInt32(result);
                        }
                    }
                    sqlquery = "Insert into ProductFeedbacks values (@feedbackid, @menuitemid);";
                    using (SqlCommand cm = new SqlCommand(sqlquery, con))
                    {
                        cm.Parameters.AddWithValue("@feedbackid", feedbackID);
                        cm.Parameters.AddWithValue("@menuitemid", itemID);
                        cm.ExecuteNonQuery();
                    }
                    MessageBox.Show("Feedback Submitted");

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Feedback_Load(object sender, EventArgs e)
        {

        }
    } 
}
