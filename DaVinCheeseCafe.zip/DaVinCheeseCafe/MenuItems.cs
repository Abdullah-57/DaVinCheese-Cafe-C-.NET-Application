﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DaVinCheeseCafe
{
    public partial class MenuItems : UserControl
    {
        public MenuItems()
        {
            InitializeComponent();
            
        }
        public int UserID;
        public void PopulateMenuGrid()
        {
            try
            {
                string connectionString = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;"; 
         


                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT P.Name, P.Price, P.Calories, P.Description from MenuItems M join Products P on M.ProductID=P.ProductID;";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    MenuGrid.Rows.Clear();

                    while (reader.Read())
                    {
                        MenuGrid.Rows.Add(reader["Name"], reader["Price"], reader["Calories"], reader["Description"]);
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int Quantity = int.Parse(itemqty.Text);
            try
            {
                if (MenuGrid.SelectedRows.Count > 0)
                {
                    DataGridViewRow selectedRow = MenuGrid.SelectedRows[0];
                    int menuItemID = GetMenuItemID(selectedRow.Cells[0].Value.ToString());

                    string connectionString = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";
                    int cartID;
                    string cartQuery = "select CartID from Customers where Customers.UserID=@UserID;";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        SqlCommand command = new SqlCommand(cartQuery, connection);
                        command.Parameters.AddWithValue("@UserID", UserID);
                        cartID = (int)command.ExecuteScalar();
                    }
                    int checker=UpdateStock(menuItemID,Quantity);
                    if (checker == 0) 
                    {
                    MessageBox.Show("Not enough stock.");
                        return;
                    }
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string insertQuery = "INSERT INTO CartItems (CartID, MenuItemID, Qty) VALUES (@CartID, @MenuItemID, @Qty)";
                        SqlCommand command = new SqlCommand(insertQuery, connection);
                        command.Parameters.AddWithValue("@CartID", cartID); 
                        command.Parameters.AddWithValue("@MenuItemID", menuItemID);
                        command.Parameters.AddWithValue("@Qty",Quantity);
                        command.ExecuteNonQuery();
                    }

                    MessageBox.Show("Item added to cart successfully.");
                }
                else
                {
                    MessageBox.Show("Please select a menu item to add to the cart.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            itemqty.Text = "1";
        }
       
        private int UpdateStock(int menuItemID,int Quantity) 
        {

            string connectionString = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";
            int stock = 0;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "select I.Quantity from Inventories I join Products P on I.ProductID=P.ProductID join MenuItems Mi on Mi.ProductID=P.ProductID where Mi.MenuItemID=@MenuitemID;";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@MenuitemID", menuItemID);
                stock = (int)command.ExecuteScalar();
            }
            if (stock < Quantity) 
            {
                return 0;
            }
           
            return 1;
        }
        private int GetMenuItemID(string Pname) 
        {

            string connectionString = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";
            int menuItemID = 0;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "select Mi.MenuItemID from MenuItems Mi join Products P on Mi.ProductID=P.ProductID where P.Name=@PName;";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@PName", Pname);
                menuItemID = (int)command.ExecuteScalar();
            }

            return menuItemID;
        }

        private void addqtybtn_Click(object sender, EventArgs e)
        {

            itemqty.Text = (int.Parse(itemqty.Text) + 1).ToString();
        }

        private void minusqtrybrn_Click(object sender, EventArgs e)
        {
            if(int.Parse(itemqty.Text)>0)
            itemqty.Text = (int.Parse(itemqty.Text) - 1).ToString();
        }

        bool feedbacktrigger=false;
        private void button2_Click(object sender, EventArgs e)
        {
            if (MenuGrid.SelectedRows.Count > 0)
            {
                string selectedMenuItemName = MenuGrid.SelectedRows[0].Cells[0].Value.ToString();
                int menuItemID = GetMenuItemID(selectedMenuItemName);

                feedback1.userID = UserID;
                feedback1.itemID = menuItemID;

                if (feedbacktrigger)
                {
                    feedbacktrigger = false;
                    button2.BackColor = Color.IndianRed;
                    feedback1.Visible = false;
                    this.BackColor = Color.RosyBrown;
                }
                else
                {
                    feedbacktrigger = true;
                    button2.BackColor = Color.Firebrick;
                    feedback1.Visible = true;
                    this.BackColor = Color.DarkSalmon;
                }
            }
            else
            {
                MessageBox.Show("Please select a menu item.");
            }
        }

        private void itemqty_Click(object sender, EventArgs e)
        {

        }

        private void MenuGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}