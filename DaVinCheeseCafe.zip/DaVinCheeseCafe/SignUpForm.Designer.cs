﻿namespace DaVinCheeseCafe
{
    partial class SignUpForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SignUpForm));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.FirstN = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.LastN = new System.Windows.Forms.Label();
            this.pass = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.passconf = new System.Windows.Forms.Label();
            this.FName = new System.Windows.Forms.TextBox();
            this.LName = new System.Windows.Forms.TextBox();
            this.Emails = new System.Windows.Forms.TextBox();
            this.Password = new System.Windows.Forms.TextBox();
            this.SignupBtn = new System.Windows.Forms.Button();
            this.Contactn = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.Label();
            this.contact = new System.Windows.Forms.Label();
            this.PasswordCon = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(46, 98);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(234, 426);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Firebrick;
            this.label1.Font = new System.Drawing.Font("Perpetua Titling MT", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(27, 18);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(291, 45);
            this.label1.TabIndex = 1;
            this.label1.Text = "SIGNUP PAGE";
            // 
            // FirstN
            // 
            this.FirstN.AutoSize = true;
            this.FirstN.BackColor = System.Drawing.Color.RosyBrown;
            this.FirstN.Font = new System.Drawing.Font("Rockwell", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FirstN.ForeColor = System.Drawing.Color.Maroon;
            this.FirstN.Location = new System.Drawing.Point(425, 98);
            this.FirstN.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.FirstN.Name = "FirstN";
            this.FirstN.Size = new System.Drawing.Size(122, 25);
            this.FirstN.TabIndex = 2;
            this.FirstN.Text = "First Name";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 18);
            this.label2.TabIndex = 15;
            // 
            // LastN
            // 
            this.LastN.AutoSize = true;
            this.LastN.BackColor = System.Drawing.Color.RosyBrown;
            this.LastN.Font = new System.Drawing.Font("Rockwell", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LastN.ForeColor = System.Drawing.Color.Maroon;
            this.LastN.Location = new System.Drawing.Point(429, 170);
            this.LastN.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LastN.Name = "LastN";
            this.LastN.Size = new System.Drawing.Size(118, 25);
            this.LastN.TabIndex = 4;
            this.LastN.Text = "Last Name";
            // 
            // pass
            // 
            this.pass.AutoSize = true;
            this.pass.BackColor = System.Drawing.Color.RosyBrown;
            this.pass.Font = new System.Drawing.Font("Rockwell", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pass.ForeColor = System.Drawing.Color.Maroon;
            this.pass.Location = new System.Drawing.Point(435, 406);
            this.pass.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.pass.Name = "pass";
            this.pass.Size = new System.Drawing.Size(110, 25);
            this.pass.TabIndex = 5;
            this.pass.Text = "Password";
            this.pass.Click += new System.EventHandler(this.pass_Click);
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(0, 0);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 18);
            this.label5.TabIndex = 0;
            // 
            // passconf
            // 
            this.passconf.AutoSize = true;
            this.passconf.BackColor = System.Drawing.Color.RosyBrown;
            this.passconf.Font = new System.Drawing.Font("Rockwell", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passconf.ForeColor = System.Drawing.Color.Maroon;
            this.passconf.Location = new System.Drawing.Point(346, 474);
            this.passconf.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.passconf.Name = "passconf";
            this.passconf.Size = new System.Drawing.Size(199, 25);
            this.passconf.TabIndex = 6;
            this.passconf.Text = "Confirm Password";
            this.passconf.Click += new System.EventHandler(this.passconf_Click);
            // 
            // FName
            // 
            this.FName.BackColor = System.Drawing.Color.WhiteSmoke;
            this.FName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.FName.Font = new System.Drawing.Font("Poor Richard", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FName.Location = new System.Drawing.Point(563, 96);
            this.FName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.FName.Name = "FName";
            this.FName.Size = new System.Drawing.Size(196, 28);
            this.FName.TabIndex = 7;
            this.FName.TextChanged += new System.EventHandler(this.FName_TextChanged);
            // 
            // LName
            // 
            this.LName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LName.Font = new System.Drawing.Font("Poor Richard", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LName.Location = new System.Drawing.Point(563, 168);
            this.LName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LName.Name = "LName";
            this.LName.Size = new System.Drawing.Size(196, 28);
            this.LName.TabIndex = 11;
            // 
            // Emails
            // 
            this.Emails.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Emails.Font = new System.Drawing.Font("Poor Richard", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Emails.Location = new System.Drawing.Point(563, 245);
            this.Emails.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Emails.Name = "Emails";
            this.Emails.Size = new System.Drawing.Size(196, 28);
            this.Emails.TabIndex = 12;
            this.Emails.TextChanged += new System.EventHandler(this.Emails_TextChanged);
            // 
            // Password
            // 
            this.Password.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Password.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Password.Location = new System.Drawing.Point(559, 409);
            this.Password.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(176, 26);
            this.Password.TabIndex = 13;
            this.Password.UseSystemPasswordChar = true;
            this.Password.TextChanged += new System.EventHandler(this.Password_TextChanged);
            // 
            // SignupBtn
            // 
            this.SignupBtn.BackColor = System.Drawing.Color.Firebrick;
            this.SignupBtn.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.SignupBtn.FlatAppearance.BorderSize = 2;
            this.SignupBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Black;
            this.SignupBtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Maroon;
            this.SignupBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SignupBtn.Font = new System.Drawing.Font("Perpetua Titling MT", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SignupBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.SignupBtn.Location = new System.Drawing.Point(848, 482);
            this.SignupBtn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.SignupBtn.Name = "SignupBtn";
            this.SignupBtn.Size = new System.Drawing.Size(195, 98);
            this.SignupBtn.TabIndex = 14;
            this.SignupBtn.Text = "SIGNUP";
            this.SignupBtn.UseVisualStyleBackColor = false;
            this.SignupBtn.Click += new System.EventHandler(this.SignupBtn_Click);
            // 
            // Contactn
            // 
            this.Contactn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Contactn.Font = new System.Drawing.Font("Poor Richard", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Contactn.Location = new System.Drawing.Point(563, 328);
            this.Contactn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Contactn.Name = "Contactn";
            this.Contactn.Size = new System.Drawing.Size(196, 28);
            this.Contactn.TabIndex = 16;
            this.Contactn.TextChanged += new System.EventHandler(this.Contactn_TextChanged);
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(0, 0);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(80, 18);
            this.label7.TabIndex = 0;
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.BackColor = System.Drawing.Color.RosyBrown;
            this.email.Font = new System.Drawing.Font("Rockwell", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email.ForeColor = System.Drawing.Color.Maroon;
            this.email.Location = new System.Drawing.Point(469, 246);
            this.email.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(69, 25);
            this.email.TabIndex = 17;
            this.email.Text = "Email";
            this.email.Click += new System.EventHandler(this.email_Click);
            // 
            // contact
            // 
            this.contact.AutoSize = true;
            this.contact.BackColor = System.Drawing.Color.RosyBrown;
            this.contact.Font = new System.Drawing.Font("Rockwell", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contact.ForeColor = System.Drawing.Color.Maroon;
            this.contact.Location = new System.Drawing.Point(422, 328);
            this.contact.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.contact.Name = "contact";
            this.contact.Size = new System.Drawing.Size(127, 25);
            this.contact.TabIndex = 18;
            this.contact.Text = "Contact No";
            this.contact.Click += new System.EventHandler(this.contact_Click);
            // 
            // PasswordCon
            // 
            this.PasswordCon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PasswordCon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PasswordCon.Location = new System.Drawing.Point(558, 474);
            this.PasswordCon.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.PasswordCon.Name = "PasswordCon";
            this.PasswordCon.Size = new System.Drawing.Size(176, 26);
            this.PasswordCon.TabIndex = 19;
            this.PasswordCon.UseSystemPasswordChar = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Firebrick;
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(2, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(338, 602);
            this.panel1.TabIndex = 20;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Perpetua Titling MT", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(18, 418);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(295, 32);
            this.label4.TabIndex = 12;
            this.label4.Text = "DaVinCheese Cafe";
            // 
            // SignUpForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.RosyBrown;
            this.ClientSize = new System.Drawing.Size(1085, 599);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.PasswordCon);
            this.Controls.Add(this.contact);
            this.Controls.Add(this.email);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Contactn);
            this.Controls.Add(this.SignupBtn);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.Emails);
            this.Controls.Add(this.LName);
            this.Controls.Add(this.FName);
            this.Controls.Add(this.passconf);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.pass);
            this.Controls.Add(this.LastN);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.FirstN);
            this.ForeColor = System.Drawing.Color.Maroon;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "SignUpForm";
            this.Text = "SignUpForm";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label FirstN;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label LastN;
        private System.Windows.Forms.Label pass;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label passconf;
        private System.Windows.Forms.TextBox FName;
        private System.Windows.Forms.TextBox LName;
        private System.Windows.Forms.TextBox Emails;
        private System.Windows.Forms.TextBox Password;
        private System.Windows.Forms.Button SignupBtn;
        private System.Windows.Forms.TextBox Contactn;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.Label contact;
        private System.Windows.Forms.TextBox PasswordCon;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
    }
}