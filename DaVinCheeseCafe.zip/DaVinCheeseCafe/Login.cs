﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Contracts;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace DaVinCheeseCafe
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string email, pass;
            email = emailbox.Text;
            pass = passwordbox.Text;

            string cnstring = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";

            string sqlquery = "SELECT UserID FROM Users WHERE Email = @Email AND Password = @Password;";
            try
            {
                int userID = 0;
                using (SqlConnection con = new SqlConnection(cnstring))
                {
                    con.Open();
                    using (SqlCommand cm = new SqlCommand(sqlquery, con))
                    {
                        cm.Parameters.AddWithValue("@Email", email);
                        cm.Parameters.AddWithValue("@Password", pass);
                        userID = Convert.ToInt32(cm.ExecuteScalar());
                    }

                    if (userID != 0)
                    {
                        string customerQuery = "select CustomerID from CustomerDetails where UserID=@UserID;";
                        using (SqlCommand customerCmd = new SqlCommand(customerQuery, con))
                        {
                            customerCmd.Parameters.AddWithValue("@UserID", userID);
                            object customerResult = customerCmd.ExecuteScalar();
                            if (customerResult != null && customerResult != DBNull.Value)
                            {
                                CustomerForm customerForm = new CustomerForm(userID);
                                customerForm.Show();
                                this.Close();
                                return;
                            }
                        }

                        string staffQuery = "select StaffID from StaffDetails where UserID=@UserID;";
                        using (SqlCommand staffCmd = new SqlCommand(staffQuery, con))
                        {
                            staffCmd.Parameters.AddWithValue("@UserID", userID);
                            object staffResult = staffCmd.ExecuteScalar();
                            if (staffResult != null && staffResult != DBNull.Value)
                            {
                                StaffLanding staffForm = new StaffLanding(userID);
                                staffForm.Show();
                                this.Close();
                                return;
                            }
                        }

                        string managerQuery = "select ManagerID from ManagerDetails where UserID=@UserID;";
                        using (SqlCommand managerCmd = new SqlCommand(managerQuery, con))
                        {
                            managerCmd.Parameters.AddWithValue("@UserID", userID);
                            object managerResult = managerCmd.ExecuteScalar();
                            if (managerResult != null && managerResult != DBNull.Value)
                            {
                                ManagerLanding managerForm = new ManagerLanding(userID);
                               
                                managerForm.Show();
                                this.Close();
                                return;
                            }
                        }

                        MessageBox.Show("Unrecognized user", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Invalid email or password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void emailbox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
