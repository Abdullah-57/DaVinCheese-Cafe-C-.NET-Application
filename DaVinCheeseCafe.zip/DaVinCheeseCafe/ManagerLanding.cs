﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DaVinCheeseCafe
{
    public partial class ManagerLanding : Form
    {
        private int activeID;
        private bool trig1 = false, trig2 = false, trig3 = false;
        private bool trig4 = false, trig5 = false, trig6 = false;
        private bool trig7 = false;
        public ManagerLanding(int id)
        {
            InitializeComponent();

            activeID = id;
        }
        private void addEmployeeDetailBtn_Click(object sender, EventArgs e)
        {
            if (trig3==false) 
            {

                trig3 = true;
                addEmployeeDetailBtn.BackColor = Color.IndianRed;
                editEmployeeDetail1.Visible = true;
                editEmployeeDetail1.PopulateEmployeeList();
                this.BackColor = Color.DarkSalmon;
            }
            else
            {
                trig3 = false;
                addEmployeeDetailBtn.BackColor = Color.Firebrick;
                editEmployeeDetail1.Visible = false;
                this.BackColor = Color.RosyBrown;

            }

        }

        private void viewSalesButton_Click(object sender, EventArgs e)
        {
            if (trig2 == false) 
            {
            
                trig2 = true;
                viewSalesButton.BackColor = Color.IndianRed;
                viewSalesForm.Visible = true;
                viewSalesForm.PopulateGrid();
            viewSalesForm.FindStarAndDog();
                this.BackColor = Color.DarkSalmon;

            }
            else 
            {
                trig2 = false;
                viewSalesButton.BackColor = Color.Firebrick;
                viewSalesForm.Visible = false;
                this.BackColor = Color.RosyBrown;

            }

        }

        private void changeproductinfobtn_Click(object sender, EventArgs e)
        {
            if (trig4 == false)
            {
                editProductDetailsForm1.FetchProducts();
                trig4 = true;
                changeproductinfobtn.BackColor = Color.IndianRed;
                editProductDetailsForm1.Visible = true;
                this.BackColor = Color.DarkSalmon;

            }
            else
            {
                trig4 = false;
                changeproductinfobtn.BackColor = Color.Firebrick;
                editProductDetailsForm1.Visible = false;
                this.BackColor = Color.RosyBrown;

            }
        }

        private void textBox1_MouseClick(object sender, MouseEventArgs e)
        {
            managerHome1.activeId = activeID;
            managerHome1.FetchManagerData();
            managerHome1.Visible = managerHome1.Visible ? false : true;
        }

        private void addSpecialDiscountButton_Click(object sender, EventArgs e)
        {
            addSpecialDiscountsForm1.activeID= activeID;
            if (trig5 == false)
            {
                trig5 = true;
                addSpecialDiscountButton.BackColor = Color.IndianRed;
                addSpecialDiscountsForm1.Visible = true;
                this.BackColor = Color.DarkSalmon;
            }
            else
            {
                trig5 = false;
                addSpecialDiscountButton.BackColor = Color.Firebrick;
                addSpecialDiscountsForm1.Visible = false;
                this.BackColor = Color.RosyBrown;

            }
        }

        private void Inventorybtn_Click(object sender, EventArgs e)
        {
            if (trig6 == false)
            {
                addInventoryForm1.PopulateGrid();
                trig6 = true;
                Inventorybtn.BackColor = Color.IndianRed;
                addInventoryForm1.Visible = true;
                this.BackColor = Color.DarkSalmon;
            }
            else
            {
                trig6 = false;
                Inventorybtn.BackColor = Color.Firebrick;
                addInventoryForm1.Visible = false;
                this.BackColor = Color.RosyBrown;
            }
        }

       
       
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }


        private void addEmployeeButton_Click(object sender, EventArgs e)
        {
            if (trig1 == false)
            {
                trig1 = true;
                addEmployeeForm.Visible = true;
                addEmployeeButton.BackColor = Color.IndianRed;
                this.BackColor = Color.DarkSalmon;
            }
            else
            {
                trig1 = false;
                addEmployeeForm.Visible = false;
                addEmployeeButton.BackColor = Color.Firebrick;
                this.BackColor = Color.RosyBrown;
            }
        }
    }
}
