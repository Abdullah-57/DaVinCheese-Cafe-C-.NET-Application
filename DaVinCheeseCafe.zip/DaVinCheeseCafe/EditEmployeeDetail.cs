﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DaVinCheeseCafe
{
    public partial class EditEmployeeDetail : UserControl
    {
        public EditEmployeeDetail()
        {
            InitializeComponent();
        }
        public void PopulateEmployeeList()
        {
            dataGridView2.Rows.Clear();
            string cnstring= "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";
            string sqlquery = "select U.FirstName,U.LastName,U.Email,U.ContactNo,S.AuthorityLevel,S.SalesCount from Staff S join Users U on S.UserID=U.UserID group by S.AuthorityLevel,S.SalesCount,U.FirstName,U.LastName,U.Email,U.ContactNo having S.AuthorityLevel<2;";
            try
            {
                using (SqlConnection con = new SqlConnection(cnstring))
                {
                    con.Open();
                    using (SqlCommand cm = new SqlCommand(sqlquery, con))
                    {
                        using (SqlDataReader dr = cm.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                string fname = dr["FirstName"].ToString();
                                string lname = dr["LastName"].ToString();
                                string email = dr["Email"].ToString();
                                string contact = dr["ContactNo"].ToString();
                                string auth = dr["AuthorityLevel"].ToString();
                                string sales = dr["SalesCount"].ToString();
                                dataGridView2.Rows.Add(fname,lname,email,contact,auth,sales);

                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
