﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DaVinCheeseCafe
{
    public partial class AddSpecialDiscountsForm : UserControl
    {
        public int activeID;
        public AddSpecialDiscountsForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView2.Rows.Clear();
            string cnstring = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";

            string discount = textBox2.Text;
            string desc = textBox4.Text;
            string eventname = textBox3.Text;
            int Dis = int.Parse(discount);
            string sqlquery = "select COUNT(*) from SpecialEventDetails;";
            int count = 0;
            try
            {
                using (SqlConnection con = new SqlConnection(cnstring))
                {
                    con.Open();
                    using (SqlCommand cm = new SqlCommand(sqlquery, con))
                    {
                        count = Convert.ToInt32(cm.ExecuteScalar());
                    }

                    if (count >= 1)
                    {
                        MessageBox.Show("You can only have one special event at a time", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    else
                    {

                        sqlquery = "INSERT INTO SpecialEvents values(@name,@desc,@dis,@managerid);";
                        using (SqlCommand cm = new SqlCommand(sqlquery, con))
                        {
                            cm.Parameters.AddWithValue("@name", eventname);
                            cm.Parameters.AddWithValue("@desc", desc);
                            cm.Parameters.AddWithValue("@dis", Dis);
                            cm.Parameters.AddWithValue("@managerid", activeID);
                            cm.ExecuteNonQuery();
                        }
                        sqlquery = "update Products set Price=(Price-Price*@discount/100);";
                        using (SqlCommand cm = new SqlCommand(sqlquery, con))
                        {
                            cm.Parameters.AddWithValue("@discount", Dis);
                            cm.ExecuteNonQuery();
                        }

                    }
                    sqlquery = "select Name,Price,Calories,Description from Products; ";
                    using (SqlCommand cm = new SqlCommand(sqlquery, con))
                    {
                        using (SqlDataReader dr = cm.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                string name = dr.GetString(0);
                                int price = dr.GetInt32(1);
                                int calories = dr.GetInt32(2);
                                string description = dr.GetString(3);
                                dataGridView2.Rows.Add(name, price, calories, description);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView2.Rows.Clear();
            string cnstring = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";
           string checker= "select COUNT(*) from SpecialEvents;";
            int count = 0;
            try
            {
                using (SqlConnection con = new SqlConnection(cnstring))
                {
                    con.Open();
                    using (SqlCommand cm = new SqlCommand(checker, con))
                    {
                        count = Convert.ToInt32(cm.ExecuteScalar());
                    }
                    if (count == 0)
                    {
                        MessageBox.Show("There is no special event to delete", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            string sqlquery = "delete from SpecialEvents; ";
            try 
            {

                using (SqlConnection con = new SqlConnection(cnstring))
                {
                    con.Open();
                    using (SqlCommand cm = new SqlCommand(sqlquery, con))
                    {
                        cm.ExecuteNonQuery();
                    }
                
                    sqlquery = "select Name,Price,Calories,Description from Products; ";
                    using (SqlCommand cm = new SqlCommand(sqlquery, con))
                    {
                        using (SqlDataReader dr = cm.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                string name = dr.GetString(0);
                                int price = dr.GetInt32(1);
                                int calories = dr.GetInt32(2);
                                string description = dr.GetString(3);
                                dataGridView2.Rows.Add(name, price, calories, description);
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
