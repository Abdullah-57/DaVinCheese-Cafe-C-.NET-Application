﻿using System;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;

namespace DaVinCheeseCafe
{
    public partial class SignUpForm : Form
    {
        public static bool Finder(string line, string tag)
        {
            for (int i = 0; i < line.Length; i++)
            {
                if (line[i] == tag[0])
                {
                    bool match = true;

                    for (int j = 0; j < tag.Length; j++)
                    {
                        if (i + j >= line.Length || line[i + j] != tag[j])
                        {
                            match = false;
                            break;
                        }
                    }
                    if (match)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        public SignUpForm()
        {
            InitializeComponent();
        }


        private void SignupBtn_Click(object sender, EventArgs e)
        {
            string email, pass, passcon, fname, lname;
            email = Emails.Text;
            pass = Password.Text;
            passcon = PasswordCon.Text;
            fname = FName.Text;
            lname = LName.Text;
            string contactnum = Contactn.Text;


            if (string.IsNullOrWhiteSpace(email) || !Finder(email, "@gmail.com"))
            {
                MessageBox.Show("Please Enter a valid Email ending with @gmail.com", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (string.IsNullOrWhiteSpace(fname))
            {
                MessageBox.Show("Please Enter a valid FirstName", "Invalid FirstName", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (string.IsNullOrWhiteSpace(lname))
            {
                MessageBox.Show("Please Enter a valid LastName", "Invalid LastName", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (pass.Length < 8 || !pass.Any(char.IsUpper) || !pass.Any(char.IsLower) || !(pass.Any(char.IsDigit) || pass.Any(char.IsPunctuation)))
            {
                MessageBox.Show("Please Enter a Password with length greater than 8, containing both uppercase and lowercase letters, and at least one number or special character", "Weak Password", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }




            if (string.IsNullOrWhiteSpace(contactnum) || contactnum.Length != 11)
            {
                MessageBox.Show("Please Enter a valid ContactNum", "Invalid ContactNum", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            string cnstring = "Data Source=DESKTOP-G3PT36A\\SQLEXPRESS;Initial Catalog=DaVinCheeseCafe;Integrated Security=True;";

            string sqlquery = "INSERT INTO Users (FirstName, LastName, Email, Password, ContactNo) VALUES (@FirstName, @LastName, @Email, @Password, @ContactNo);SELECT SCOPE_IDENTITY();";
            try
            {
                using (SqlConnection con = new SqlConnection(cnstring))
                {
                    con.Open();
                    int userid = 0;
                    using (SqlCommand cm = new SqlCommand(sqlquery, con))
                    {
                        cm.Parameters.AddWithValue("@FirstName", fname);
                        cm.Parameters.AddWithValue("@LastName", lname);
                        cm.Parameters.AddWithValue("@Email", email);
                        cm.Parameters.AddWithValue("@Password", pass);
                        cm.Parameters.AddWithValue("@ContactNo", contactnum);
                        userid = Convert.ToInt32(cm.ExecuteScalar()); // Retrieve the latest UserID
                    }

                    sqlquery = "INSERT INTO Carts VALUES (0); SELECT SCOPE_IDENTITY();";
                    int cartid = 0;
                    using (SqlCommand cm = new SqlCommand(sqlquery, con))
                    {
                        cartid = Convert.ToInt32(cm.ExecuteScalar());
                    }

                    sqlquery = "INSERT INTO Customers (LoyaltyPoints, UserID, CartID) VALUES (0, @UserID, @CartID)";
                    using (SqlCommand cm = new SqlCommand(sqlquery, con))
                    {
                        cm.Parameters.AddWithValue("@UserID", userid);
                        cm.Parameters.AddWithValue("@CartID", cartid);
                        cm.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Record inserted successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            PasswordCon.Text = "";
            Password.Text = "";
            Emails.Text = "";
            FName.Text = "";
            LName.Text = "";
            Contactn.Text = "";

        }



        private void passconf_Click(object sender, EventArgs e)
        {

        }

        private void Password_TextChanged(object sender, EventArgs e)
        {

        }

        private void contact_Click(object sender, EventArgs e)
        {

        }

        private void email_Click(object sender, EventArgs e)
        {

        }

        private void Emails_TextChanged(object sender, EventArgs e)
        {

        }

        private void Contactn_TextChanged(object sender, EventArgs e)
        {

        }

        private void pass_Click(object sender, EventArgs e)
        {

        }

        private void FName_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
